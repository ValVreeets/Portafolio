# Tetris

Andrés, Bryan y Valeria

## Objetivo y alcance

Crear una versión en java de tetris que se pueda jugar en la terminal. El juego, además de las reglas tradicionales, cuenta con nuevas
reglas especiales, relacionados con los colores aleatorios que tiene cada pieza.

## Cómo compilar y ejecutar

Se compila el proyecto de java y se ejecuta inicializando la clase Main.

## Controles

para cada accion se debe presionar "enter"
- "e" para rotar en sentido de las manecillas del reloj
- "q" para rotar en contra de las manecillas del reloj
- "a" para mover la pieza a la izquierda
- "d" para mover la pieza a la derecha
- "s" para mover la pieza hacia abajo (esto lo hace automáticamente)

## Decisiones de diseño

Funciones como Gravedad y Movimientos tienen sus propias clases para no saturar la clase Tetris donde está la lógica del juego.
La clase Tetris simplemente crea una instancia de la clase, enviándole el mapa del juego como parámetro y recupera el nuevo 
mapa del juego con un getter. Para las piezas también se creo una clase propia que de manera similar recive el mapa y devuelve
el nuevo mapa, con la diferencia de que contiene (como atributos) las coordenadas de la pieza, para que estas puedan ser 
enviadas con facilidad a movimientos. Además esta la clase PantalladeJuego que se encarga de imprimir todo lo que se le muestra
al usuario. La clase Extras solo es para que se pueda imprimir en color. Finalmente, en ComboColores se encuentra el árbol y se 
manera todo lo de puntaje.

## Limitaciones conocidas y trabajo futuro

Al estar una pieza contra la pared o otra pieza el código no es capaz de automáticamente mover la pieza
en la dirección necesaria para realizar la rotación. Se debe presionar enter entre cada movimiento. Además,
las piezas no bajan automáticamente con el tiempo como en la versión real de tetris.
