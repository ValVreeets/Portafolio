/**
 * Mantiene el control de lo que se le muestra al usuario, es decir el mapa del juego y el puntaje
 * @author Andres, Bryan, Valeria
 * @version 1.0
 */
public class PantalladeJuego {
    private int puntaje;


    public PantalladeJuego(){
        puntaje = 0;
    }
    

    
    /**
     *  Actualiza el tablero en la terminal
     */
    public void imprimirMapaJuego(String[][] mapaJuego){
        System.out.println();
        for(int i=0; i<20; i++){
            for(int j=0; j<10; j++){
                System.out.print(" "+mapaJuego[i][j]+" ");
            }
            System.out.println();
        }
        System.out.println("PUNTAJE: " + puntaje);
    }


    public void setPuntaje( int newPoints){
        puntaje += newPoints;
    }
   
    public int getPuntaje(){
        return puntaje;
    }



}
