/**
 * Clase de manejo del juego
 * @author Andres, Bryan, Valeria
 * @version 2.0 
 * */
public class Tetris {
    private String[][] mapaJuego;
    private boolean vivo;
    private boolean ganar;
    private PantalladeJuego screen;
    private ComboColores combos;
 

    public Tetris(){
        screen = new PantalladeJuego();
        combos = new ComboColores();
        mapaJuego = new String[20][10];
        llenarMapaJuego();
        vivo=true;
        ganar = false;

        while(vivo == true && ganar == false){ 
            Pieza piz = new Pieza(mapaJuego); //genera nueva pieza
            mapaJuego = piz.getPiezainMapa();  //version mapa ya con pieza
            screen.imprimirMapaJuego(mapaJuego); 
            Movimientos mov = new Movimientos(piz,mapaJuego, screen); //mobilidad de la pieza
            mapaJuego = mov.getPostmapa();//devuleve matriz actual
            piz = null;
            mov = null;;
            chequeoMatrizLineaLlena(); //chequeo de lineas
            Gravedad grav = new Gravedad(mapaJuego); 
            mapaJuego = grav.getPostmapa(); 
            screen.imprimirMapaJuego(mapaJuego);
            vivo = !looseGame();
        }

        if (!vivo){
            System.out.print("Ha perdido.");
        }
    }


   /**
    *  Limpia completamente el tablero de piezas
    */
    private void llenarMapaJuego(){
        for(int i=0; i<20; i++){
            for(int j=0; j<10; j++){
                mapaJuego[i][j]="-";
            }
        }
    }

    /**
     * chequea si las piezas han tocado el limite superior
     * @param collusion dice si existe una colision entre el techo y la montana de piezas
     * @param chequeo verifica si una columan en especifico esta llena
     * @return booleano de si toco techo de matriz
     */

    private boolean looseGame(){ 
        boolean collusion = false;
        for (int i = 0; i < 10 ; i++){
            boolean chequeo = chequeoColumnas(0,i);
            if (chequeo == true){
                collusion = true;
            }
        }
        return collusion;  
    }


    /**
     * Chequea si una columna en especifico esta llena
     * @return true si esta llena
     * @error columna y debe siempre comenzar con un 0 introducido.
     */
    private boolean chequeoColumnas(int y, int x){
        if (mapaJuego[y][x] !=  "-"){
                if (y == 19){
                     return true;
                } else if (mapaJuego[y+1][x] != "-" && y+1 < 20){
                return chequeoColumnas(y+1, x);
                 }else{
                     return false;
                 }
        }else{
            return false;
        }
        
    }
    
    /**
     *  va espacio por espacio en una columna verificando si se crea ua racha de 4 elementos con el mismo color
     * @param colorRacha color que se va repitiendo
     * @param listaCombo lista que guarda los colores conforme se van repitiendo
     * @param listaFinal lista a devolver, con las filas a las que pertenecen los colores repetidos
     * @return lista de filas a borrar
     */
    private int[] coloresColumna(int x){
        String colorRacha = "";
        int[] listaCombo = new int[4];
        int[] listaFinal = null;
        int contador = 0;
        for (int i = 19 ; i >= 0; i --){
            if( !mapaJuego[i][x].equals("-")){
                 String colorActual = colorPedazo(i,x);
                if (colorRacha.equals(colorActual)){ //mantiene la racha
                    contador++;
                    listaCombo[contador] = i;
                    if (contador >= 3){
                        listaFinal = listaCombo;
                        break;
                    }
                }else{
                    colorRacha = colorActual; //si se rompe la racha
                    listaCombo = null;
                    listaCombo = new int[4];
                    contador = 0;
                    listaCombo[contador] = i;
                }
            }
        
        }
        return listaFinal;
    }


    /**
     * Chequea una linea entera especifica iniciando en la izquierda
     * @return booleano que te dice si esta full llena la linea
     * @error no funciona bien si no comienza en la izquierda maxima
     */
    private boolean chequeoLineaRomper(int y, int x){
        if ( x+1  >= 10){
            return true;
           
        }else if ( x+1 < 10 && mapaJuego [y][x+1] != "-" && mapaJuego[y][x] != "-"){
            return chequeoLineaRomper(y, x+1);
        }else{
            return false;
        }
     }
    

     /**
      * verifica el caso de si una linea esta llena y tambien de si se repite un color 4 veces
      * @param huboCambio true si se modifico la frecuencia de los colores
      * @param lineas lista de 1 linea a meter en Puntos
      * @param columnas lista de filas a meter en Puntos
      */
     private void chequeoMatrizLineaLlena(){
        boolean huboCambio = false;
        for (int i = 19; i > 0; i--){ //cada fila
            if (chequeoLineaRomper(i,0)){ //suma puntos y rompe fila si es verdad
                int[] lineas = new int[1];
                lineas[0] = i;
                puntos(lineas);
                huboCambio = true;
            }
        }
        boolean huboCambio2 = false;
        for (int i = 0; i < mapaJuego[0].length ; i++){
            int[] columnas = coloresColumna(i);
            if (columnas != null){
                puntos(columnas);
                huboCambio2 = true;
            }
        } 
        if (huboCambio == true || huboCambio2 == true){
            combos.ordenar(); 
        }
    }





  
/**
 * especificamente borra una linea completa
 *
 */ 
     private void limpiarLineas(int[] lineas){ 
        for ( int x : lineas ){
            for (int i = 0; i < mapaJuego[x].length; i++){
                mapaJuego[x][i] = "-";
            }
        }
    }
    
     /**
      * Va elemento por elemento en una fila llena agregando el uso del color al arbol
      @param color color de ese elemento de linea en especifico
      @error al iniciar, debe comenzar con el espacio 0 de la fila
      */
    private void agregarUsoColoresLinea(int y){
        for ( int i = 0; i < 10 ; i++){
            if (!mapaJuego[y][i].equals("-")){
                String color = colorPedazo (y, i);
                 combos.cambiarFrecuencia(color);
            }
    }  

     }

     /**
      * chequea color del pedazo y lo devuleve
      * @return color del pedazo en formato String
      */
    private String colorPedazo(int y, int x){
          String color = "";
        if (mapaJuego[y][x].contains(Extras.Amarillo)){
            color = "Amarillo";
        }else if  (mapaJuego[y][x].contains(Extras.Azul)){
            color = "Azul";
        }else if  (mapaJuego[y][x].contains(Extras.Morado)){
            color = "Morado";
        }else if  (mapaJuego[y][x].contains(Extras.Rojo)){
            color = "Rojo";
        }else if  (mapaJuego[y][x].contains(Extras.Verde)){
            color = "Verde";
        }
        return color;
    }

    /**
     * cuenta cantidad de cada color en una linea y dice cual es el mayor;
     * @param listaColores guarda la info numerica de cada uso de color
     * @param listaColoresNombres guarda los nombres de cada color y tiene relacion == posicion con listaColores
     * @return string con color dominante de esa linea
     */
    private String hallarColorDominante(int y){
        int rojo = 0; int azul = 0; int amarillo = 0; int morado = 0; int verde = 0;
        for (int i = 0; i < 10; i++){
            String color = colorPedazo(y,i);
            if ("Amarillo".equals(color)){
                amarillo++;
            }else if ("Azul".equals(color)){
                azul++;
            }else if ("Morado".equals(color)){
                morado++;
            }else if ("Rojo".equals(color)){
                rojo++;
            }else if ("Verde".equals(color)){
                verde++;
            }
        }
        int [] listaColores =  { amarillo, azul,  morado, rojo, verde};
        String[] listaColoresNombres = {"Amarillo", "Azul","Morado", "Rojo", "Verde"};
        int dominante = 0;
        for (int j = 1; j < listaColores.length; j++){
            if (listaColores[j] > listaColores[dominante]){
                dominante = j;
            }
        }
        return listaColoresNombres[dominante];
    }

        /**
         * Funcion que realiza todos los calculos para agregar a la puntuacion y luego borra las lineas
         * @param puntajeTotal cantidad a sumar al puntaje
         * @param combo numero por el que se multiplica el puntaje conseguido en caso de repetir dominante
         * @param racha num de colores repetidos seguidos
         * @param coloractual color del pedazo actual dominante
         * @param colorpedazo color de un pedazo en especifico de la matriz
         * @param puntosColor puntos a sumar dependiendo del valor de un color en especifico en el arbol
         * 
         */
         private void puntos(int[] lineas){
            int puntajeTotal = 0;
            int combo = 1;
            String racha = "";
            String coloractual;
            for (int y : lineas){
                int puntos = 0;
                agregarUsoColoresLinea(y); //agrega al arbol los usos de linea entera
                for (int j = 0; j < 10; j++){ // suma los puntajes por cada color en la linea
                    String colorpedazo = colorPedazo(y,j);
                        if (colorpedazo != null && !colorpedazo.equals("")){
                            int puntosColor = combos.getValorColor(colorpedazo);
                            puntos += puntosColor;
                        }
                }
                coloractual = hallarColorDominante(y);
                    if (racha.equals(coloractual)){
                    combo++;
                }else{
                    racha = coloractual;
                    combo = 1;
                }
                puntajeTotal += puntos;
            }
                screen.setPuntaje(puntajeTotal*combo);
                limpiarLineas(lineas);
            }



        







}


    
   