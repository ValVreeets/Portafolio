public class Extras {

//para aplicar un color Extras.rojo + "texto" 
public static final String Reset = "\u001B[0m";
public static final String Rojo = "\u001B[31m";
public static final String Verde = "\u001B[32m";
public static final String Amarillo = "\u001B[33m";
public static final String Azul = "\u001B[34m";
public static final String Morado = "\u001B[35m";

//Fondos por si acaso es necesario
 public static final String FondoRojo = "\u001B[41m";
    public static final String FondoVerde = "\u001B[42m";
    public static final String FondoAmarillo = "\u001B[43m";
    public static final String FondoAzul = "\u001B[44m";
    public static final String FondoMorado = "\u001B[45m";
    public static final String FondoBlanco = "\u001B[47m";

}
    

