
/**
 * Coloca una pieza random sobre la matriz y genera sus coordenadas correspondientes
 * @author Andres, Valeria, Bryan
 * @version 2.0
 */
public class Pieza {



    private String[] pedazos;
    private int x1; private int y1;
    private int x2; private int y2;
    private int x3; private int y3;
    private int x4; private int y4;
    private int piezaElegida;
    private String[][] mapaJuego;


    public Pieza(String[][] mapa){
            mapaJuego = mapa;
            pedazos = new String[4];
            piezaElegida= (int) (Math.random()*7);
            agregarPieza(piezaElegida);
    }



    /**
     * Funcion para generar  una pieza aleatoria en el tablero desde 7 tipos de piezas distintas de 4 pedazos cada uno.
     * @param piezaElegida  valor random que se recibe del constructor 
     * @param y1 posicion en columan 1 del pedazo.
     * @param y2 posicion en columan 2 del pedazo.
     * @param y3 posicion en columan 3 del pedazo.
     * @param y4 posicion en columan 4 del pedazo.
     * @param x1 posicion en fila 1 del pedazo.
     * @param x2 posicion en fila 2 del pedazo.
     * @param x3 posicion en fila 3 del pedazo.
     * @param x4 posicion en fila 4 del pedazo.
     * @param mapaJuego matriz que cumple el rol del tablero en la terminal 
     */
    private void agregarPieza(int piezaElegida){
        for(int i=0; i<4; i++){
            int colorPieza=(int)(Math.random()*5);
            switch (colorPieza){
                case 0:
                    pedazos[i]=Extras.Amarillo+"■"+Extras.Reset;
                    break;
                case 1:
                    pedazos[i]=Extras.Azul+"■"+Extras.Reset;
                    break;
                case 2:
                    pedazos[i]=Extras.Morado+"■"+Extras.Reset;
                    break;
                case 3:
                    pedazos[i]=Extras.Rojo+"■"+Extras.Reset;
                    break;
                case 4:
                    pedazos[i]=Extras.Verde+"■"+Extras.Reset;
                    break;
            }
        }

        if(piezaElegida==0){//T
            y1=0; x1=3; y2=0; x2=4; y3=0; x3=5; y4=1; x4=4;
            mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
        }else if(piezaElegida==1){//Cuadrado
            y1=0; x1=4; y2=0; x2=5; y3=1; x3=4; y4=1; x4=5;
            mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
        }else if(piezaElegida==2){ //I
            y1=0; x1=4; y2=1; x2=4; y3=2; x3=4; y4=3; x4=4;
            mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
        }else if(piezaElegida==3){// L invertida
            y1=0; x1=5; y2=1; x2=5; y3=2; x3=5; y4=2; x4=4;
            mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
        }else if(piezaElegida==4){//L
            y1=0; x1=4; y2=1; x2=4; y3=2; x3=4; y4=2; x4=5;
            mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
        }else if(piezaElegida==5){//Saprissa
            y1=0; x1=4; y2=1; x2=4; y3=1; x3=5; y4=2; x4=5;
            mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
        }else if(piezaElegida==6){
            y1=0; x1=5; y2=1; x2=5; y3=1; x3=4; y4=2; x4=4;
            mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
        }
    }
    
    public String[][]  getPiezainMapa(){
            return mapaJuego;
        }
    public int  getPiezaElegida(){
            return piezaElegida;
        }

    public String[] getPedazos(){
        return pedazos;
    }


    public int getX1(){
        return x1;
    }
     public int getX2(){
        return x2;
    }
     public int getX3(){
        return x3;
    }
     public int getX4(){
        return x4;
    }

     public int getY1(){
        return y1;
    }
       public int getY2(){
        return y2;
    }
       public int getY3(){
        return y3;
    }
       public int getY4(){
        return y4;
    }





    

}
