/**
 * Hace que las lineas bajen si no hay nada debajo de ellas
 * @author Andres, Bryan, Valeria
 * @version 2.0
 */
public class Gravedad {
    private String[][] mapaJuego;
    private int lineaVaciaEncontrada;
    public Gravedad(String[][] mapaRecivido){
        mapaJuego=mapaRecivido;
        lineaVaciaEncontrada=encontrarLineaVacia(19);//busca primera linea vacia de abajo para arriba
        if(lineaVaciaEncontrada>0){//se asegura de que no sea la ultima
            while(todasLasLineasDeArribaVacias(lineaVaciaEncontrada)==false){//mientras haya algo que pueda caer
                while(lineaVacia(lineaVaciaEncontrada,0)==true){//se trae para abajo hasta que llene la primera linea vacia que se encontro
                    bajarLineas(lineaVaciaEncontrada);
                }
                lineaVaciaEncontrada=encontrarLineaVacia(19);
            }
        }
    }
    public String[][] getPostmapa(){
        return mapaJuego;
    }
    /**
     * funcion recursiva que encuentra la primera linea vacia de abajo para arriba
     * @param linea es el int de la linea a chequear, va disminuyendo por lo que para revisar el mapa completo se debe inicializar en 19
     * @return el int de la linea vacia que se encontro
     */
    private int encontrarLineaVacia(int linea){
        if(linea==0){
            return 0;
        }else{
            if(lineaVacia(linea, 0)==true){
                return linea;
            }else{
                return encontrarLineaVacia(linea-1);
            }
        }
    }
    /**
     * funcion recursiva que verifica si una linea se encuentra vacia o no
     * @param linea es el int de la linea a chequear
     * @param parteDeLaLinea es el int de la parte de la linea que se esta chequeando, va aumentando por lo que se debe inicializar en 0
     * @return true si la linea esta vacia
     */
    private boolean lineaVacia(int linea, int parteDeLaLinea){
        if(parteDeLaLinea==9){
            if(mapaJuego[linea][parteDeLaLinea].equals("-")){
                return true;
            }else{
                return false;
            }
        }else{
            if(mapaJuego[linea][parteDeLaLinea].equals("-")){
                return lineaVacia(linea, parteDeLaLinea+1);
            }else{
                return false;
            }
        }
    }
    /**
     * funcion recursiva que baja un cuadro todo lo que este sobre la linea vacia que no sea vacio
     * @param lineaDondeSeEmpieza es la primera linea vacia que se encontro donde se empieza a revisar para arriba
     */
    private void bajarLineas(int lineaDondeSeEmpieza){
        if(lineaDondeSeEmpieza==0){
            //Se acabo la busqueda pq ya no tiene linea superior
        }else{
            if(lineaVacia(lineaDondeSeEmpieza-1,0)==false){
                for(int i = lineaDondeSeEmpieza; i > 0; i--){
                    for(int j = 0; j < mapaJuego[i].length; j++){
                        mapaJuego[i][j] = mapaJuego[i-1][j];
                    }
                }
                
                for(int j = 0; j < mapaJuego[0].length; j++){
                    mapaJuego[0][j] = "-";
                }
            }else{
                bajarLineas(lineaDondeSeEmpieza-1);
            }
        }
    }
    /**
     * funcion recursiva que verifica si todas linea que estan sobre la primera linea vacia encontrada estan vacias, empieza revisando en la linea que se envia por lo que no funciona si se le envia una linea que no esta vacia
     * @param linea es la linea que se esta chequeando que debe inicializarse con una linea vacia
     * @return true si sobre la linea vacia enviada como parametro solo hay vacio
     */
    private boolean todasLasLineasDeArribaVacias(int linea){
        if(linea==0){
            if(lineaVacia(linea,0)==true){
                return true;
            }else{
                return false;
            }
        }else{
            if(lineaVacia(linea,0)==true){
                return todasLasLineasDeArribaVacias(linea-1);
            }else{
                return false;
            }
        }
    }

}

