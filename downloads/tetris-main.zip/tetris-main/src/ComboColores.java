import java.util.List;
import java.util.ArrayList;
import java.util.Collections;
/**
 * Maneja el arbol de colores
 * @author Andres, Bryan, Valeria
 * @version 2.0
 */
public class ComboColores {
    private class Color{
        public int combo;
        public String nombre;
        public Color left;
        public Color right;

        public Color(){
            combo = 1;
            nombre = "vacio";
            left = null;
            right = null;
        }
        public Color(String name){
            nombre = name;
            combo = 1;
            left = null;
            right = null;
        }
    }



    private Color raiz;
    public ComboColores(){
        raiz = new Color("Rojo");
        raiz.left = new Color("Verde");
        raiz.right = new Color ("Azul");
        raiz.left.left = new Color ("Amarillo");
        raiz.right.right = new Color ("Morado");
    }



    /**
     * Busca en el arbol un color especifico
     * @param  temp Nodo en el arbol actual
     * @param found Nodo que se busca
     * @error debe ingresarse la raiz al inicializar la funcion
     * @return Nodo que se busca
     */
    public Color buscarColor(Color color, String name){ 
        if (color.nombre.equals(name)){
            return color;
        }else{
            Color hallado = null;
            if (color.left != null){
                hallado = buscarColor(color.left, name);
            }
            if (hallado == null && color.right != null){
                hallado = buscarColor(color.right,name);
            }
            return hallado;
        }
    }




    /**  Funcion que paso a paso reacomoda el arbol.
     * @param lista lista normal donde se agregaran los elementos 
     * @param mitad posicion del valor mas aproximado a la mitad de la lista 
     */
      public void ordenar(){

        List<Color> lista = hacerLista(raiz);
        //bubble sort
        int tamano = lista.size();
        for (int i = 0; i < tamano - 1; i++){
            for (int j = 0; j < tamano-i-1; j++){
                if (lista.get(j).combo > lista.get(j+1).combo){
                    Collections.swap(lista, j , j+1);
                }     
            }
        }
        limpiarReferencias(lista);
        rehacerArbol(lista);
        }
    




    /**
     * limpia todas las referencias de los nodos color 
     */
    private void limpiarReferencias( List<Color> lista){
        for (Color c : lista){
            c.right = null;
            c.left = null;
        }
    }


    /**
     * Crea lista de los nodos del arbol Colores. Pre Order
     * @param listaOrdenacion lista donde se copiaran los elementos
     */
    private List<Color>  hacerLista(Color color){ 
        List<Color> listaOrdenacion = new ArrayList <> (); 
        inOrderCopia(raiz, listaOrdenacion);
        return listaOrdenacion;
    }

    /**
     * coloca el arbol en una lista leyendolo in orden
     * @param color inicialmente se le envia la raiz
     * @param listaOrdenacion lista para colocar los elementos
     */
    private void inOrderCopia(Color color, List<Color> listaOrdenacion){
        if ( color != null){
            if (color.left != null){
                inOrderCopia(color.left,listaOrdenacion );
            }
            listaOrdenacion.add(color);
            if (color.right != null){
                inOrderCopia(color.right,listaOrdenacion );
            }
        }
    }


    /**
     *  rehace el arbol a partir de un dato ingresado como centro
     * @param raiz cabeza/inicio del arbol. Valor del medio
     * @param lista lista ya ordenada de los colores segun su nivel de uso
     * @param num posicion en la lista de colores
     * @error si corre, pero da malos resultados si no se mete el valor del medio.
     */
    private void rehacerArbol(List<Color> lista){
        raiz = lista.get((lista.size()/2));
        int num = lista.indexOf(raiz);
        raiz.left = lista.get(num-1);
        raiz.right = lista.get(num+1);
        raiz.left.left = lista.get(num-2);
        raiz.right.right = lista.get(num+2);
    }



    
 
    
    
    /**
     * //cada vez que se rompe un cuadrito de suma a ese color 
     * @param sumado color al que se le sumara el uso
     * @param nombre color usado durante el combo
     * @raiz nodo central del arbol de Colores 
     */
    public void cambiarFrecuencia(String nombre){
        Color color = buscarColor(raiz, nombre);
        color.combo += 1;
    }


    public int  getValorColor(String nombre){
        Color color = buscarColor(raiz, nombre);
        return color.combo;

    }


    public Color getRaiz(){
        return raiz;
    }

}


















