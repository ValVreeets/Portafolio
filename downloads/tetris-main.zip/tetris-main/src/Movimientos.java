import java.util.Scanner;

/**
 * Se encarga de hacer que las piezas se muevan para abajo, la izquierda, la derecha y roten tanto para la derecha como para la izquierda
 * @author Andres, Bryan, Valeria
 * @version 2.0
 */
public class Movimientos {
    private Scanner input;
    private int y1;
    private int y2;
    private int y3;
    private int y4;
    private int x1;
    private int x2;
    private int x3;
    private int x4;
    private String[][] mapaJuego;
    private int piezaElegida;
    private String[] pedazos;
    private PantalladeJuego screen;

    public Movimientos( Pieza piz,String[][] mapa, PantalladeJuego pantalla){
        mapaJuego= mapa;
        screen = pantalla;
        y1 = piz.getY1();
        y2 = piz.getY2();
        y3 = piz.getY3();
        y4 = piz.getY4();
        x1 = piz.getX1();
        x2 = piz.getX2();
        x3 = piz.getX3();
        x4 = piz.getX4();
        piezaElegida = piz.getPiezaElegida();
        pedazos = piz.getPedazos();
        moverPieza();
    }  



   
    /**
     * Permite mover de distintas formas la pieza conforme cae en el tablero con WASD y ENTER hasta llegar a una restriccion
     * @param inputU input de teclas 
     * @param todaviaSePuedeMover  booleano que limita hasta donde esta permitido seguir moviendose
     */
    
    private void moverPieza(){
        input = new Scanner(System.in);
        boolean todaviaSePuedeMover = true;
        while(todaviaSePuedeMover){
            String inputU = "O";
            if(y1==19 || y2==19 || y3==19 || y4==19){//Revisa si llega abajo
                todaviaSePuedeMover=false;
            }else{
                mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";//Limpia los espacios para no revisarse a si mismo
                if(!(mapaJuego[y1+1][x1].equals("-") && mapaJuego[y2+1][x2].equals("-") && mapaJuego[y3+1][x3].equals("-") && mapaJuego[y4+1][x4].equals("-"))){//Revisa si hay una pieza abajo
                    todaviaSePuedeMover=false;
                }
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];//Lo pone como estaba
            }
            
            inputU=input.nextLine();
            if(inputU.toLowerCase().equals("a")){
                moverIzquierda();
                moverAbajo();//
            }else if(inputU.toLowerCase().equals("s")){
                moverAbajo();
            }else if(inputU.toLowerCase().equals("d")){
                moverDerecha();
                moverAbajo();//
            }else if(inputU.toLowerCase().equals("e")){  
                rotarDerecha();
                 moverAbajo();//
            }else if(inputU.toLowerCase().equals("q")){
                rotarIzquierda();
                moverAbajo();//
            }
            else if(inputU.toLowerCase().equals("w")){
                moverArriba();
            }else{
                moverAbajo();
            }
            
            if(y1<19 && y2<19 && y3<19 && y4<19){
                mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
                if(mapaJuego[y1+1][x1].equals("-") && mapaJuego[y2+1][x2].equals("-") && mapaJuego[y3+1][x3].equals("-") && mapaJuego[y4+1][x4].equals("-")){
                    todaviaSePuedeMover = true; 
                }  
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
            } 
            screen.imprimirMapaJuego(mapaJuego);
        } 
    }



    /**
     * Getter para el mapa del juego
     * @return el mapa del juego ojala modificado por la clase
     */
    public String [][] getPostmapa(){
        return mapaJuego;
    }
    
    
    
    /**
     * permite desplazarse hacia abajo con la pieza a menos que algun espacio abajo no este libre
     */
    private void moverAbajo(){
        if(y1<19 && y2<19 && y3<19 && y4<19){
            mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
            if(mapaJuego[y1+1][x1].equals("-") && mapaJuego[y2+1][x2].equals("-") && mapaJuego[y3+1][x3].equals("-") && mapaJuego[y4+1][x4].equals("-")){
                y1+=1; y2+=1; y3+=1; y4+=1; 
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
            }
        }
    }
    
    
    
    
    /**
     * permite desplazarse hacia la derecha con la pieza a menos que algun espacio de los 4 no este disponible
     */
    private void moverDerecha(){
        if(x1<9 && x2<9 && x3<9 && x4<9){
            mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
            if(mapaJuego[y1][x1+1].equals("-") && mapaJuego[y2][x2+1].equals("-") && mapaJuego[y3][x3+1].equals("-") && mapaJuego[y4][x4+1].equals("-")){
                x1+=1; x2+=1; x3+=1; x4+=1; 
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
            }
        }
    }




    /**
     * permite desplazarse hacia la izquierda  con la pieza a menos que algun espacio de los no este libre
     */
    private void moverIzquierda(){
        if(x1>0 && x2>0 && x3>0 && x4>0){
            mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
            if(mapaJuego[y1][x1-1].equals("-") && mapaJuego[y2][x2-1].equals("-") && mapaJuego[y3][x3-1].equals("-") && mapaJuego[y4][x4-1].equals("-")){
                x1-=1; x2-=1; x3-=1; x4-=1; 
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
            }
        }
    }
    
    
    
    /**
     * permite desplazarse hacia arriba con la pieza (no debaria estar es cheat code para los devs)
     */
    private void moverArriba(){
        if(y1>0 && y2>0 && y3>0 && y4>0){
            mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
            if(mapaJuego[y1-1][x1].equals("-") && mapaJuego[y2-1][x2].equals("-") && mapaJuego[y3-1][x3].equals("-") && mapaJuego[y4-1][x4].equals("-")){
                y1-=1; y2-=1; y3-=1; y4-=1; 
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
            }
        }
    }

    /**
     * permite rotar la pieza en el sentido de las manecillas del reloj a menos de que los campos donde quedaria la pieza estan ocupadas
     */
    private void rotarDerecha(){
        if(piezaElegida!=2){
            if(y2>0 && y2<19 && x2>0 && x2<9){
                if(sePuedeRotarR(x1,y1)&&sePuedeRotarR(x3,y3)&&sePuedeRotarR(x4,y4)){
                    rotarOrillasR();
                    rotarEsquinasR();
                }
            }
        //rotar la pieza I    
        }else{
            if (sePuedeRotarIR(x1, y1, x4, y4)){

                mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";

                if(x4==x2 && y4==y2+2){ //vertical hacia abajo
                    y1+=1; x1+=1;
                    y3-=1; x3-=1;
                    y4-=2; x4-=2;
                }else if(x4==x2-2 && y4==y2){ //horizontal hacia la izquierda
                    y1+=1; x1-=1;
                    y3-=1; x3+=1;
                    y4-=2; x4+=2;
                }else if(x4==x2 && y4==y2-2){ //vertical hacia arriba
                    y1-=1; x1-=1;
                    y3+=1; x3+=1;
                    y4+=2; x4+=2;
                }else if(x4==x2+2 && y4==y2){ //horizontal hacia la derecha
                    y1-=1; x1+=1;
                    y3+=1; x3-=1;
                    y4+=2; x4-=2;
                }
            }

        mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
        }
        
    }


    /**
     * permite rotar la pieza en sentido contrario a las manecillas del reloj a menos de que los campos donde quedarian la pieza estan ocupados
     */
    private void rotarIzquierda(){
        if(piezaElegida!=2){
            if(y2>0 && y2<19 && x2>0 && x2<9){
                if(sePuedeRotarL(x1,y1)&&sePuedeRotarL(x3,y3)&&sePuedeRotarL(x4,y4)){
                    rotarOrillasL();
                    rotarEsquinasL();
                }
            }
        //rotar la pieza I    
        }else{
            if (sePuedeRotarIL(x1, y1, x4, y4)){

                mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";

                if(x4==x2 && y4==y2+2){ //vertical hacia abajo
                    y1+=1; x1-=1;
                    y3-=1; x3+=1;
                    y4-=2; x4+=2;
                }else if(x4==x2-2 && y4==y2){ //horizontal hacia la izquierda
                    y1-=1; x1-=1;
                    y3+=1; x3+=1;
                    y4+=2; x4+=2;
                }else if(x4==x2 && y4==y2-2){ //vertical hacia arriba
                    y1-=1; x1+=1;
                    y3+=1; x3-=1;
                    y4+=2; x4-=2;
                }else if(x4==x2+2 && y4==y2){ //horizontal hacia la derecha
                    y1+=1; x1+=1;
                    y3-=1; x3-=1;
                    y4-=2; x4-=2;
                }
            }

        mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
        }
        
    }



    /**
     * parte especifica de rotarDerecha que se encarga del movimiento de los pedazos que no estan en diagonal al centro
     */
    private void rotarOrillasR(){
        mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
        if(x1==x2 && y1==y2-1){//esta arriba del centro
            y1+=1; x1+=1;
        }else if(x1==x2+1 && y1==y2){//esta a la derecha del centro
            y1+=1; x1-=1;
        }else if(x1==x2 && y1==y2+1){//esta abajo del centro
            y1-=1; x1-=1;
        }else if(x1==x2-1 && y1==y2){//esta a la izquierda del centro
            y1-=1; x1+=1;
        }
        if(x3==x2 && y3==y2-1){//esta arriba del centro
            y3+=1; x3+=1;
        }else if(x3==x2+1 && y3==y2){//esta a la derecha del centro
            y3+=1; x3-=1;
        }else if(x3==x2 && y3==y2+1){//esta abajo del centro
            y3-=1; x3-=1;
        }else if(x3==x2-1 && y3==y2){//esta a la izquierda del centro
            y3-=1; x3+=1;
        }
        if(x4==x2 && y4==y2-1){//esta arriba del centro
            y4+=1; x4+=1;
        }else if(x4==x2+1 && y4==y2){//esta a la derecha del centro
            y4+=1; x4-=1;
        }else if(x4==x2 && y4==y2+1){//esta abajo del centro
            y4-=1; x4-=1;
        }else if(x4==x2-1 && y4==y2){//esta a la izquierda del centro
            y4-=1; x4+=1;
        }
        mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
    }



    /**
     * parte especifica de rotarIzquierda que se encarga del movimiento de los pedazos que no estan en diagonal al centro
     */
    private void rotarOrillasL(){
        mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
        if(x1==x2 && y1==y2-1){//esta arriba del centro
            y1+=1; x1-=1;
        }else if(x1==x2+1 && y1==y2){//esta a la derecha del centro
            y1-=1; x1-=1;
        }else if(x1==x2 && y1==y2+1){//esta abajo del centro
            y1-=1; x1+=1;
        }else if(x1==x2-1 && y1==y2){//esta a la izquierda del centro
            y1+=1; x1+=1;
        }
        if(x3==x2 && y3==y2-1){//esta arriba del centro
            y3+=1; x3-=1;
        }else if(x3==x2+1 && y3==y2){//esta a la derecha del centro
            y3-=1; x3-=1;
        }else if(x3==x2 && y3==y2+1){//esta abajo del centro
            y3-=1; x3+=1;
        }else if(x3==x2-1 && y3==y2){//esta a la izquierda del centro
            y3+=1; x3+=1;
        }
        if(x4==x2 && y4==y2-1){//esta arriba del centro
            y4+=1; x4-=1;
        }else if(x4==x2+1 && y4==y2){//esta a la derecha del centro
            y4-=1; x4-=1;
        }else if(x4==x2 && y4==y2+1){//esta abajo del centro
            y4-=1; x4+=1;
        }else if(x4==x2-1 && y4==y2){//esta a la izquierda del centro
            y4+=1; x4+=1;
        }
        mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
    }



    /**
     * parte especifica de rotarDerecha que se encarga del movimiento de los pedazos que estan en diagonal al centro
     */
    private void rotarEsquinasR(){
        mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
        if(x1==x2-1 && y1==y2-1){//esta arriba y a la izquierda del centro
            x1+=2;
        }else if(x1==x2+1 && y1==y2-1){//esta arriba y a la derecha del centro
            y1+=2;
        }else if(x1==x2+1 && y1==y2+1){//esta abajo y a la derecha del centro
            x1-=2;
        }else if(x1==x2-1 && y1==y2+1){//esta abajo y a la izquierda del centro
            y1-=2;
        }
        if(x3==x2-1 && y3==y2-1){//esta arriba y a la izquierda del centro
            x3+=2;
        }else if(x3==x2+1 && y3==y2-1){//esta arriba y a la derecha del centro
            y3+=2;
        }else if(x3==x2+1 && y3==y2+1){//esta abajo y a la derecha del centro
            x3-=2;
        }else if(x3==x2-1 && y3==y2+1){//esta abajo y a la izquierda del centro
            y3-=2;
        }
        if(x4==x2-1 && y4==y2-1){//esta arriba y a la izquierda del centro
            x4+=2;
        }else if(x4==x2+1 && y4==y2-1){//esta arriba y a la derecha del centro
            y4+=2;
        }else if(x4==x2+1 && y4==y2+1){//esta abajo y a la derecha del centro
            x4-=2;
        }else if(x4==x2-1 && y4==y2+1){//esta abajo y a la izquierda del centro
            y4-=2;
        }
        mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
    }



    /**
     * parte especifica de rotarIzquierda que se encarga del movimiento de los pedazos que estan en diagonal al centro
     */
    private void rotarEsquinasL(){
        mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
        if(x1==x2-1 && y1==y2-1){//esta arriba y a la izquierda del centro
            y1+=2;
        }else if(x1==x2+1 && y1==y2-1){//esta arriba y a la derecha del centro
            x1-=2;
        }else if(x1==x2+1 && y1==y2+1){//esta abajo y a la derecha del centro
            y1-=2;
        }else if(x1==x2-1 && y1==y2+1){//esta abajo y a la izquierda del centro
            x1+=2;
        }
        if(x3==x2-1 && y3==y2-1){//esta arriba y a la izquierda del centro
            y3+=2;
        }else if(x3==x2+1 && y3==y2-1){//esta arriba y a la derecha del centro
            x3-=2;
        }else if(x3==x2+1 && y3==y2+1){//esta abajo y a la derecha del centro
            y3-=2;
        }else if(x3==x2-1 && y3==y2+1){//esta abajo y a la izquierda del centro
            x3+=2;
        }
        if(x4==x2-1 && y4==y2-1){//esta arriba y a la izquierda del centro
            y4+=2;
        }else if(x4==x2+1 && y4==y2-1){//esta arriba y a la derecha del centro
            x4-=2;
        }else if(x4==x2+1 && y4==y2+1){//esta abajo y a la derecha del centro
            y4-=2;
        }else if(x4==x2-1 && y4==y2+1){//esta abajo y a la izquierda del centro
            x4+=2;
        }
        mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
    }


    /**
     * recive las coordenadas de un pedazo y decide donde quedaria el pedazo al rotar hacia la derecha y revisa el espacio para verificar que este vacio
     * @param x es la coordenada x del pedazo
     * @param y es la coordenada y del pedazo
     * @return true si los espacios donde aterrizaran las piezas estan vacias y falso si no
     */
    private boolean sePuedeRotarR(int x, int y){
        mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
        if(x==x2 && y==y2-1){//esta arriba del centro
            if(mapaJuego[y+1][x+1].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2+1 && y==y2){//esta a la derecha del centro
            if(mapaJuego[y+1][x-1].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2 && y==y2+1){//esta abajo del centro
            if(mapaJuego[y-1][x-1].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2-1 && y==y2){//esta a la izquierda del centro
            if(mapaJuego[y-1][x+1].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2-1 && y==y2-1){//esta arriba y a la izquierda del centro
            if(mapaJuego[y][x+2].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2+1 && y==y2-1){//esta arriba y a la derecha del centro
            if(mapaJuego[y+2][x].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2+1 && y==y2+1){//esta abajo y a la derecha del centro
            if(mapaJuego[y][x-2].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2-1 && y==y2+1){//esta abajo y a la izquierda del centro
            if(mapaJuego[y-2][x].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else{
            mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
            return false;
        }
    }



    /**
     * recive las coordenadas de un pedazo y decide donde quedaria el pedazo el rotar hacia la izquierda y revisa el espacio para verificar que este vacio
     * @param x es la coordenada x del pedazo
     * @param y es la coordenada y del pedazo
     * @return true si los espacios donde aterrizaran las piezas estan vaciaas y falso si no
     */
    private boolean sePuedeRotarL(int x, int y){
        mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
        if(x==x2 && y==y2-1){//esta arriba del centro
            if(mapaJuego[y+1][x-1].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2+1 && y==y2){//esta a la derecha del centro
            if(mapaJuego[y-1][x-1].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2 && y==y2+1){//esta abajo del centro
            if(mapaJuego[y-1][x+1].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2-1 && y==y2){//esta a la izquierda del centro
            if(mapaJuego[y+1][x+1].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2-1 && y==y2-1){//esta arriba y a la izquierda del centro
            if(mapaJuego[y+2][x].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2+1 && y==y2-1){//esta arriba y a la derecha del centro
            if(mapaJuego[y][x-2].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2+1 && y==y2+1){//esta abajo y a la derecha del centro
            if(mapaJuego[y-2][x].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else if(x==x2-1 && y==y2+1){//esta abajo y a la izquierda del centro
            if(mapaJuego[y][x+2].equals("-")){
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return true;
            }else{
                mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
                return false;
            }
        }else{
            mapaJuego[y1][x1]=pedazos[0]; mapaJuego[y2][x2]=pedazos[1]; mapaJuego[y3][x3]=pedazos[2]; mapaJuego[y4][x4]=pedazos[3];
            return false;
        }
    }




    /**
     * caso especial para la pieza I que recive las coordenadas del pedazo 1 y 4 (dos de un solo) y revisa si los espacios donde aterrizarian al rotar hacia la derecha estan vacios
     * @param x1 es la coordenada x del pedazo 1
     * @param y1 es la coordenada y del pedazo 1
     * @param x4 es la coordenada x del pedazo 4
     * @param y4 es la coordenada y del pedazo 4
     * @return true si los espacios correspondientes estan vacios y false si no
     */
    private boolean sePuedeRotarIR(int x1, int y1, int x4, int y4){
        mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
        //Vertical hacia abajo
        if(x4==x2 && y4==y2+2 && 
        //limites
         x2 > 1 && x2 < 9 && 
         //obstruccion
         mapaJuego[y1+1][x1+1].equals("-") && mapaJuego[y3-1][x3-1].equals("-") &&
         mapaJuego[y4-2][x4-2].equals("-")){ return true; } 

        //Horizontal hacia la izquierda
        else if(x4==x2-2 && y4==y2 && 
        //limites
        y2 > 1 && y2 < 19 &&
        //obstruccion
        mapaJuego[y1+1][x1-1].equals("-") && mapaJuego[y3-1][x3+1].equals("-") && 
        mapaJuego[y4-2][x4+2].equals("-")){ return true; } 
           
        //Vertical hacia arriba
        else if(x4==x2 && y4==y2-2 &&
        //limites
        x2 < 8 && x2 > 0 && 
        //obstruccion
        mapaJuego[y1-1][x1-1].equals("-") && mapaJuego[y3+1][x3+1].equals("-")
        && mapaJuego[y4+2][x4+2].equals("-")){ return true; } 
        //Horizontal hacia la derecha
        else if(x4==x2+2 && y4==y2 && 
        //limites
        y2 < 18 && y2 > 0 
        //obstruccion
        && mapaJuego[y1-1][x1+1].equals("-") && mapaJuego[y3+1][x3-1].equals("-")
        && mapaJuego[y4+2][x4-2].equals("-")){ return true; } 
        else {
            return false;
        }

       
    }


    /**
     * caso especial para la pieza I que recive las coordenadas del pedazo 1 y 4 (dos de un solo) y revisa si los espacios donde aterrizarian al rotar hacia la izquierda estan vacios
     * @param x1 es la coordenada x del pedazo 1
     * @param y1 es la coordenada y del pedazo 1
     * @param x4 es la coordenada x del pedazo 4
     * @param y4 es la coordenada y del pedazo 4
     * @return true si los espacios correspondientes estan vacios y false si no
     */
    private boolean sePuedeRotarIL(int x1, int y1, int x4, int y4){
        mapaJuego[y1][x1]="-"; mapaJuego[y2][x2]="-"; mapaJuego[y3][x3]="-"; mapaJuego[y4][x4]="-";
        //Vertical hacia abajo
        if(x4==x2 && y4==y2+2 && 
        //limites
         x2 > 0 && x2 < 8 && 
         //obstruccion
         mapaJuego[y1+1][x1-1].equals("-") && mapaJuego[y3-1][x3+1].equals("-") && 
         mapaJuego[y4-2][x4+2].equals("-")){ return true; } 

        //Horizontal hacia la izquierda
        else if(x4==x2-2 && y4==y2 && 
        //limites
        y2 > 0 && y2 < 18 &&
        //obstruccion
        mapaJuego[y1-1][x1-1].equals("-") && mapaJuego[y3+1][x3+1].equals("-") && 
        mapaJuego[y4+2][x4+2].equals("-")){ return true; } 
           
        //Vertical hacia arriba
        else if(x4==x2 && y4==y2-2 &&
        //limites
        x2 < 9 && x2 > 1 && 
        //obstruccion
        mapaJuego[y1-1][x1+1].equals("-") && mapaJuego[y3+1][x3-1].equals("-") && 
        mapaJuego[y4+2][x4-2].equals("-")){ return true; } 
           
        //Horizontal hacia la derecha
        else if(x4==x2+2 && y4==y2 && 
        //limites
        y2 < 19 && y2 > 1 && 
        //obstruccion
        mapaJuego[y1+1][x1+1].equals("-") && mapaJuego[y3-1][x3-1].equals("-") && 
        mapaJuego[y4-2][x4-2].equals("-")){ return true; } 
        else {
            return false;
        }
        
    }

}