import java.util.Random;
/**
 * Chequea la vida de los pokemones para determinar si estan debilitados, determina el orden de los turnos segun la velocidad
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */



public class Calculos {

    private Random random = new Random();
    private Input input = new Input();
    private AccionesNpc accionesNpc;
    private Records records;
  
    public Calculos(Records num){
        records = num;
        accionesNpc = new AccionesNpc(records);
    }


/**
 *si toda la lista esta debilitada retorna falso
 * @param vivos numero de Pokemones aun vivos
 * @param sigueCombate determina si es verdad que siguen pokemones vivos
 * @return verdadero o falso sobre si quedan pokemones vivos 
 */


    public boolean chequearVidaEquipo( Pokemon[] listaPokemones ){
        int vivos = 0;
        boolean sigueCombate = true;
        for ( Pokemon pokemon : listaPokemones){
            if (pokemon.getStats().getHp() != 0){
                vivos ++;
            }
        }
        if (vivos == 0){
            sigueCombate = false;
        }
        return sigueCombate;

    }

/**
 *Devuelve lista con los pokemones ordenados por velocidad.
 * @param  orden lista de los pokemones ya ordenados por velocidad
 * @param p1 pokemon 1
 * @param p2 pokemon 2
 * @return  la lista de pokemones ordenados por velocidad
 */

    public Pokemon[] Velocidad( Pokemon P1, Pokemon P2){
        Pokemon[] orden = new Pokemon[2];
        if (P1.getStats().getSpd() > P2.getStats().getSpd()){
            orden[0] = P1;
            orden[1] = P2;
        }else if (P1.getStats().getSpd() == P2.getStats().getSpd()){
            orden[random.nextInt(2)] = P1;
            if (orden[0] == P1){
                orden[1] = P2;
            }else{
                orden[0] = P2;
            }

        }else {
            orden[0] = P2;
            orden[1] = P1;
        }
        return orden;
    
    }

/**
 * Toma los datos de los dos pokemones y el ataque elegido para determinar cuanto dano se hizo
 * @param enemy determina si el pokemon es del enemigo o no
 * @param ataque ataque a calcular
 * @param atacante Pokemon que va a realizar el ataque 
 * @param victima Pokemon que recibe el ataque
 * @param potencia potencia del atacante
 * @param precision precision del atacante
 * @param hp vida de la victima
 * @param nivel nivel del atacante
 * @param defensa defensa de la victima
 * @critico valor para calcular el critico de un ataque 
 * @param tipoDebi valor en la formula si el elemento pertenece a la lista de Debilidades
 * @param tipoFort valor en la formula si el elemento pertenece a la lista de Fortalezas
 * @param tipoInmu valor en la formula si el elemento pertenece a la lista de Inmunidades
 * @param records objeto Records que guarda informacion varia sobre los combates
 */
    // el purisimo calculo matematico del ataque y la resta al hp
    public void  Ataque( Ataque ataque, Pokemon atacante, Pokemon victima, boolean enemy){
        if (enemy == true){
            System.out.printf("\n%s enemigo ha utilizado %s.", atacante.getNombre(), ataque.getNombre());
        }else{
            System.out.printf("\n%s ha utilizado %s.", atacante.getNombre(), ataque.getNombre());
        }

        int potencia = ataque.getPotencia();
        int precision = ataque.getPrecision();
        double hp = victima.getStats().getHp();
        double atk = atacante.getStats().getAtk();
        double nivel = atacante.getNivel();
        double defensa = victima.getStats().getDef();
        double critico = 1;
        int tipoDebi = 1;
        double  tipoFort = 1;
        int tipoInmu = 1;
        
        for ( String  element : victima.getElemento().getDebilidades()){
            if (ataque.getElemento().getNombre() == element){
                tipoDebi = 2;
               
                break;
            }    
        }
        for ( String  element : victima.getElemento().getFortalezas()){
            if (ataque.getElemento().getNombre() == element){
                tipoFort = 0.5;
                
                break;
            }    
        }
        for ( String  element : victima.getElemento().getInmunidades()){
            if (ataque.getElemento().getNombre() == element){
                tipoInmu = 0;
                
                break;
            }    
        }
        if(random.nextInt(100)<4){
            critico=2;
        }
        double dano = ((((((2*nivel*critico)/5)+2)*potencia*(atk/defensa))/50)+2)*tipoDebi*tipoFort*tipoInmu;
        
        if(random.nextInt(100)<precision){
            if(tipoDebi!=1){
                System.out.print("\nAtaque ha sido SUPER efectivo.");
            }else if(tipoFort!=1){
                System.out.print("\nAtaque ha sido poco efectivo.");
            }else if(tipoInmu!=1){
                System.out.print("\n...Ataque no ha causado efecto alguno");
            }
            if(critico!=1 && tipoInmu==1){
                System.out.print("\nHa dado un golpe critico");
            }
            System.out.print("\nDMG: " + Math.round (dano));
            hp = (int) Math.round (hp - dano);
            victima.getStats().setHp(Math.round (hp));
        }else{
            System.out.print("\nPero fallo");
        }


        if (enemy == true){
            records.sumartotalDMGReceived(dano);
            
        }else{
            records.sumarTotalDMG(dano);
        }
        

    }

/**
 * Le muestra al jugador la vida que le queda a los pokemones activos
 * @param activo pokemon que va a atacar
 * @param rival pokemon que recibira el ataque 
 * @param jugador Objeto entrenador que representa al jugador
 * @param npc Objeto entrenador que representa al entrenador contrincante
 * @return 
 */
    public void imprimirVida(Pokemon activo, Pokemon rival, Entrenador jugador, Entrenador npc){
        System.out.print( " \n" );
        System.out.print( " \nılıılıılılıılıılıılıılıılılıılıılı" );
        System.out.printf( "\n %s de %s lvl%.0f  HP: %.0f", activo.getNombre(),jugador.getNombre(),activo.getNivel(), activo.getStats().getHp());
        System.out.printf( "\n %s de %s lvl%.0f  HP: %.0f", rival.getNombre(), npc.getNombre(), rival.getNivel() ,rival.getStats().getHp());
        System.out.print( " \nılıılıılılıılıılıılıılıılılıılıılı" );
        System.out.print( " \n" );
    }

/**
 * Determina si el pokemon activo es el NPC para elegir un ataque random o proponerle al usuario que elija uno
 * @param  atacante Pokemon que va a atacar
 * @param  pokemonActivo pokemon en campo perteneciente al jugador
 * @param pokemonRival pokemon en campo perteneciente al npc
 * @param atk ataque por realizar 
 */
// decide cual funcion de escoger ataque va a usarse dependiendo si jugador o npc
public void ejecutarAtaque( Pokemon atacante, Pokemon pokemonActivo , Pokemon pokemonRival, Ataque atk){

    if (atacante.getdelJugador()==true){
        Ataque(atk,pokemonActivo, pokemonRival, false); 
                                    
    }else {
        Ataque(accionesNpc.RandomAtaque(pokemonRival), pokemonRival,pokemonActivo, true);
    }
}




}// fin clase 
