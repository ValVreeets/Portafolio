/**
 * Crea los entrenadores y los coloca en una lista para generar mas orden visual
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */

public class CrearEntrenadores {
    private Entrenador[] entrenadores;
    private Pokemon[] pokemones;

    public CrearEntrenadores(){
        CrearPokemones creacioninicialpokemones = new CrearPokemones();
        pokemones = creacioninicialpokemones.getPokemones();

        entrenadores = new Entrenador[10]; 

        //Guia Entrenadores:

        //Gimnasio Fuego:
        //entrenadores[0] Felicia
        //entrenadores[1] Florencio
        //entrenadores[2] Fermin

        //Gimnasio Electrico
        //entrenadores[3] Eduardo
        //entrenadores[4] Estela
        //entrenadores[5] Esteban
        //Gimnasio Agua

        //entrenadores[6] Ander
        //entrenadores[7] Amber
        //entrenadores[8] Apolo

        //entrenadores[9] placeholder


        //Felicia (Ninetales, Tepig, Arcanine)
        entrenadores[0] = new Entrenador ("Felicia", false, pokemones[3],pokemones[1], pokemones[4] );
        //Florencio (Rapidash, Braixen, Torracat)
        entrenadores[1] = new Entrenador ("Florencio", false, pokemones[5],pokemones[8], pokemones[9] );
        //Fermin (Charizard, Torchic, Chimchar)
        entrenadores[2] = new Entrenador ("Fermin", false, pokemones[2],pokemones[6], pokemones[7] );
        //Eduardo (Pikachu, Mareep, Shinx)
        entrenadores[3] = new Entrenador ("Eduardo", false, pokemones[0], pokemones[11], pokemones[12]);
        //Estela (Tynamo, Yamper, Voltorb)
        entrenadores[4] = new Entrenador ("Estela", false, pokemones[13], pokemones[14], pokemones[15]);
        //Esteban (Galvantula, Raikou, Zapdos)
        entrenadores[5] = new Entrenador ("Esteban", false, pokemones[10], pokemones[16], pokemones[17]);
        //Gimnasio Agua
        //Ander (Squirtle, Psyduck, Poliwag)
        entrenadores[6] = new Entrenador ("Ander", false, pokemones[18], pokemones[21], pokemones[23]);
        //Amber (Wartortle, Tentacool, Seel)
        entrenadores[7] = new Entrenador ("Amber", false, pokemones[19], pokemones[26], pokemones[24]);
        //Apolo (Blastoise, Kingler, Golduck)
        entrenadores[8] = new Entrenador ("Apolo", false, pokemones[20], pokemones[25], pokemones[22]);

        //placeholder
        entrenadores[9] = new Entrenador ("placeholder", false, pokemones[27],pokemones[19] , pokemones[20] );
    }

    public Entrenador[] getEntrenadores(){
    return entrenadores;
    }

    public Entrenador getEntrenador(int num){
        return entrenadores[num];
    }





        

}
