/**
 * Contiene el nombre del gimnasio y los entrenadores correspondientes en una lista
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */




public class Gimnasio {
    private String nombre;
    private Entrenador[] entrenadores;
    public Gimnasio(String nombre, Entrenador entrenador0, Entrenador entrenador1, Entrenador entrenador2){
        entrenadores = new Entrenador[3];
        this.nombre = nombre;
        entrenadores[0] = entrenador0;
        entrenadores[1] = entrenador1;
        entrenadores[2] = entrenador2;
    }


//Setters y Getters


public String getNombre(){
    return nombre;
}
public Entrenador[] getEntrenadores(){
    return entrenadores;
}
public Entrenador getEntrenador(int i){
        return entrenadores[i];
}


public void setEntrenadores( Entrenador[] entrenadores){
    this.entrenadores = entrenadores;
}
public void setNombre(String nombre){
    this.nombre = nombre;
}

}


