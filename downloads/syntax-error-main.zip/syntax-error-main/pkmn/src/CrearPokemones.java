/**
 * Crea a los pokemones y los coloca en una lista para generar mas orden visual
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */


public class CrearPokemones {
    private Pokemon[] pokemones;
    private Elemento[] elementos;

    public CrearPokemones(){
        CrearElementos creacioninicialdeelementos = new CrearElementos();
        elementos = creacioninicialdeelementos.getElementos();
        //Guia para agregar elementos a los pokemones 
        //elementos[0]=acero         //elementos[9]=tierra
        //elementos[1]=volador       //elementos[10]=fuego
        //elementos[2]=agua          //elementos[11]=lucha
        //elementos[3]=hielo         //elementos[12]=hada
        //elementos[4]=planta        //elementos[13]=psiquico
        //elementos[5]=bicho         //elementos[14]=veneno
        //elementos[6]=electrico     //elementos[15]=dragon
        //elementos[7]=normal        //elementos[16]=fantasma
        //elementos[8]=roca          //elementos[17]=siniestro  

        pokemones = new Pokemon[28]; //cambiar conforme se hagan mas pokemones a la lista

        //Pikachu 0
        Stats pikaStats = new Stats(100, 60, 50,70);
        Ataque impactrueno = new Ataque("Impactrueno", 20, 15, 100, elementos[6]);
        Ataque placaje = new Ataque("Placaje",30,10,100,elementos[7]);
        Ataque finta = new Ataque("Finta", 30, 10, 95, elementos[7]);
        Ataque bola_voltio = new Ataque("Bola voltio", 30, 15, 90, elementos[6]);
        pokemones[0] = new Pokemon("Pikachu", 30, pikaStats, elementos[6], impactrueno, placaje, finta, bola_voltio);
        

        //Tepig 1 inicio pokemones fuego (9 total) 
        //arreglar brasas
        Stats tepiStats = new Stats( 65,63,45,45);
        Ataque embestida = new Ataque ("Embestida", 45, 20, 85, elementos[7]);
        Ataque brasas = new Ataque ("Brasas",40, 13, 100, elementos[10]);
        Ataque llamarada = new Ataque ("Llamarada", 25,20,100,elementos[10]);
        Ataque cabezaso = new Ataque ("Cabezaso", 70, 5, 80, elementos[8]);
        pokemones[1] = new Pokemon("Tepig", 30, tepiStats, elementos[10], embestida, brasas, llamarada,cabezaso);

        //Charizard 2
        Stats chariStats = new Stats( 78,84,78,109);
        Ataque garraDragon = new Ataque ("Garra de dragon", 40, 15, 100, elementos[15]);
        Ataque brasaschar = new Ataque ("Brasas",20, 25, 100, elementos[10]);
        Ataque lanzallamas = new Ataque ("Lanzallamas", 45,15,100,elementos[10]);
        Ataque raspon = new Ataque ("Raspon", 20, 35, 100, elementos[7]); 
        pokemones[2] = new Pokemon("Charizard", 50, chariStats, elementos[10], garraDragon,brasaschar ,lanzallamas ,raspon);
        
        //Ninetails 3
        Stats nineStats = new Stats( 73,76,75,81);
        Ataque inferno = new Ataque ("Inferno", 50, 5, 50, elementos[10]);
        Ataque brasasnine = new Ataque ("Brasas",20, 25, 100, elementos[10]);
        Ataque incinerar = new Ataque ("Incinerar", 30,15,100,elementos[10]);
        Ataque ondaFuego = new Ataque ("Onda de Fuego", 50, 5, 85, elementos[10]);
        pokemones[3] = new Pokemon("Ninetails", 30, nineStats, elementos[10], inferno, brasasnine, incinerar,ondaFuego);

        //Arcanine 4
        Stats arcaStats = new Stats( 90,110,80,100);
        Ataque brasasarc = new Ataque ("Brasas",20, 25, 100, elementos[10]);
        Ataque mordida = new Ataque ("Mordida", 30, 25, 100, elementos[17]);
        Ataque colmilloFuego = new Ataque ("Colmillo de fuego", 30, 15, 95, elementos[10]);
        Ataque ruedaFuego = new Ataque ("Rueda de fuego", 30, 25, 100, elementos[10]);
        pokemones[4] = new Pokemon("Arcanine", 30, arcaStats, elementos[10], brasasarc,mordida ,colmilloFuego ,ruedaFuego);

        //Rapidash 5
        Stats rapiStats = new Stats( 65,100,70,80);
        Ataque brasasrapi = new Ataque ("Brasas",20, 25, 100, elementos[10]);
        Ataque ruedaFuegorapi = new Ataque ("Rueda de fuego", 30, 25, 100, elementos[10]);
        Ataque embestidarapi = new Ataque ("Embestida", 45, 20, 85, elementos[7]);
        Ataque embestidaLlamas = new Ataque ("Embestida de llamas", 25, 20, 100, elementos[10]);
        pokemones[5] = new Pokemon("Rapidash", 40, rapiStats, elementos[10], brasasrapi, ruedaFuegorapi, embestidarapi,embestidaLlamas);

        //Torchic 6
         Stats torchiStats = new Stats( 45,60,40,70);
        Ataque rasponTorchi = new Ataque ("Raspon", 20, 35, 100, elementos[7]); 
        Ataque brasastorchi = new Ataque ("Brasas",20, 25, 100, elementos[10]);
        Ataque embestidaLlamastorchi = new Ataque ("Embestida de llamas", 25, 20, 100, elementos[10]);
        Ataque ataqRapido = new Ataque ("Ataque rapido", 20, 30, 100, elementos[7]);
        pokemones[6] = new Pokemon("Torchic", 50, torchiStats, elementos[10], rasponTorchi, brasastorchi, embestidaLlamastorchi, ataqRapido);

        // Chimchar 7
         Stats chimStats = new Stats( 44,58,44,58);
        Ataque rasponChim = new Ataque ("Raspon", 20, 35, 100, elementos[7]); 
        Ataque brasaschim = new Ataque ("Brasas",20, 25, 100, elementos[10]);
        Ataque ruedaFuegochim = new Ataque ("Rueda de fuego", 30, 25, 100, elementos[10]);
        Ataque golpesFuria = new Ataque ("Golpes de furia", 9, 15, 80, elementos[7]);
        pokemones[7] = new Pokemon("Chimchar", 50, chimStats, elementos[10], rasponChim, brasaschim, ruedaFuegochim,golpesFuria);
   
        //Braixen 8
         Stats braiStats = new Stats( 59,59,58,73);
        Ataque brasasbrai = new Ataque ("Brasas",20, 25, 100, elementos[10]);
        Ataque rasponBrai = new Ataque ("Raspon", 20, 35, 100, elementos[7]); 
        Ataque embestidaLlamasBrai = new Ataque ("Embestida de llamas", 25, 20, 100, elementos[10]);
        Ataque giroFuego = new Ataque ("Giro de Fuego ", 35, 15, 85, elementos[10]);
        pokemones[8] = new Pokemon("Braixen", 40, braiStats, elementos[10], brasasbrai, rasponBrai, embestidaLlamasBrai,giroFuego);
       
  
       //Torracat 9 fin de pokemones fuego
        Stats torraStats = new Stats( 65,85,50,80);
        Ataque lamida = new Ataque ("Lamida", 15, 30, 100, elementos[16]);
        Ataque brasastorra = new Ataque ("Brasas",20, 25, 100, elementos[10]);
        Ataque rasponTorra = new Ataque ("Raspon", 20, 35, 100, elementos[7]); 
        Ataque golpesFuriaTorra = new Ataque ("Golpes de furia", 9, 15, 80, elementos[7]);
        pokemones[9] = new Pokemon("Torracat", 40, torraStats, elementos[10], lamida, brasastorra, rasponTorra, golpesFuriaTorra);

        //Galvantula 10 
        Stats galvaStats = new Stats(70, 77, 60, 108);
        Ataque galvabola_voltio = new Ataque("Bola voltio", 30, 10, 100, elementos[6]);
        Ataque picadura = new Ataque("Picadura", 3, 20, 100, elementos[5]);
        Ataque gigadrenado = new Ataque("Gigadrenado", 35, 10, 100, elementos[4]);
        Ataque electrotela = new Ataque("Electrotela", 25, 15, 95, elementos[6]);
        pokemones[10] = new Pokemon("Galvantula", 50, galvaStats, elementos[6], galvabola_voltio, picadura, gigadrenado, electrotela);
        
        //Mareep 11
        Stats mareepStats = new Stats(55, 40, 40, 35);
        Ataque mareepPlacaje = new Ataque("Placaje", 20, 35, 100, elementos[7]);
        Ataque joya_de_luz = new Ataque("Joya de luz", 40, 20, 100,elementos[8]);
        Ataque chispazo = new Ataque("Chispazo", 40, 15, 100, elementos[6]);
        Ataque trueno = new Ataque("Trueno", 50, 10, 70, elementos[6]);
        pokemones[11] = new Pokemon("Mareep", 30, mareepStats, elementos[6], mareepPlacaje, joya_de_luz, chispazo, trueno);

        //Shinx 12
        Stats shinxStats = new Stats(45, 65, 34, 45);
        Ataque mordisco = new Ataque("Mordisco", 30, 25, 100, elementos[17]);
        Ataque triturar = new Ataque("Triturar", 40, 15, 100, elementos[17]);
        Ataque chispa = new Ataque("Chispa", 33, 20, 100, elementos[6]);
        Ataque voltio_cruel = new Ataque("Voltio cruel", 45, 15, 100, elementos[6]);
        pokemones[12] = new Pokemon("Shinx", 30, shinxStats, elementos[6], mordisco, triturar, chispa, voltio_cruel);

        //tynamo 13
        Stats tynaStats = new Stats(35, 55, 40, 60);
        Ataque tynachispa = new Ataque("Chispa", 33, 20, 100, elementos[6]);
        Ataque tynaPlacaje = new Ataque("Placaje", 20, 35, 100, elementos[7]);
        Ataque rayoCarga = new Ataque("Rayo carga", 25, 10, 90, elementos[6]);
        Ataque rayo = new Ataque("Rayo", 45, 15, 100, elementos[6]);
        pokemones[13] = new Pokemon("Tynamo", 40, tynaStats, elementos[6], tynachispa, tynaPlacaje, rayoCarga, rayo);

        //yamper 14
        Stats yampStats = new Stats(59, 45, 50, 26);
        Ataque moffeteestatico = new Ataque("Moffete estatico", 10, 20, 100, elementos[6]);
        Ataque yampmordisco = new Ataque("Mordisco", 30, 25, 100, elementos[17]);
        Ataque yampchispa = new Ataque("Chispa", 32, 20, 100, elementos[6]);
        Ataque yampvoltio_cruel = new Ataque("Voltio cruel", 45, 15, 100, elementos[6]);
        pokemones[14] = new Pokemon("Yamper", 40, yampStats, elementos[6], moffeteestatico, yampmordisco, yampchispa, yampvoltio_cruel);

        //voltorb 15
        Stats voltorbStats = new Stats(40, 30, 50, 100);
        Ataque bombasonica = new Ataque("Bomba sonica", 45, 20, 90, elementos[7]);
        Ataque voltrayoCarga = new Ataque("Rayo carga", 25, 10, 90, elementos[6]);
        Ataque girobola = new Ataque("Giro bola", 50, 5, 100, elementos[6]);
        Ataque manto_espejo = new Ataque("Manto espejo", 35, 20, 100, elementos[13]);
        pokemones[15] = new Pokemon("Voltorb", 40, voltorbStats, elementos[6], bombasonica, voltrayoCarga, girobola, manto_espejo);

        //raikou 16
        Stats raikouStats = new Stats(90, 85, 75, 115);
        Ataque raitrueno = new Ataque("Trueno", 55, 10, 70, elementos[6]);
        Ataque raimordisco = new Ataque("Mordisco", 30, 25, 100, elementos[17]);
        Ataque colmillorayo= new Ataque("Colmillo rayo", 33, 20, 100, elementos[6]);
        Ataque raiimpactrueno = new Ataque("Impactrueno", 20, 15, 100, elementos[6]);
        pokemones[16] = new Pokemon("Raikou", 50, raikouStats, elementos[6], raitrueno, raimordisco, colmillorayo, raiimpactrueno);

        //zapdos 17
        Stats zapdosStats = new Stats(90, 90, 85, 100);
        Ataque electrocanon = new Ataque("Electrocanon", 70, 8, 80, elementos[6]);
        Ataque picotaladro = new Ataque("Picotaladro", 50, 8, 90, elementos[1]);
        Ataque caidalibre = new Ataque("Caidalibre", 50, 10, 95, elementos[1]);
        Ataque aladeacero = new Ataque("Ala de acero", 55, 10, 90, elementos[0]);
        pokemones[17] = new Pokemon("Zapdos", 50, zapdosStats, elementos[6], electrocanon, picotaladro, caidalibre, aladeacero);

        //Inicio pokemones agua
        //Squirtle 18
        Stats squirStats = new Stats(44, 48, 65, 50);
        Ataque pistolaAgua = new Ataque("Pistola agua", 20, 25, 100, elementos[2]);
        Ataque placajeSquir = new Ataque("Placaje", 15, 20, 100, elementos[7]);
        Ataque burbuja = new Ataque("Burbuja", 20, 30, 100, elementos[2]);
        Ataque mordiscoSquir = new Ataque("Mordisco", 30, 25, 100, elementos[17]);
        pokemones[18] = new Pokemon("Squirtle", 30, squirStats, elementos[2], pistolaAgua, placajeSquir, burbuja, mordiscoSquir);

        //Wartortle 19
        Stats warStats = new Stats(59, 63, 80, 65);
        Ataque acuaCola = new Ataque("Aqua cola", 45, 10, 90, elementos[2]);
        Ataque placajeWar = new Ataque("Placaje", 15, 20, 100, elementos[7]);
        Ataque pistolaAguaWar = new Ataque("Pistola agua", 20, 25, 100, elementos[2]);
        Ataque giroRapido = new Ataque("Giro rapido", 20, 20, 100, elementos[7]);
        pokemones[19] = new Pokemon("Wartortle", 40, warStats, elementos[2], acuaCola, placajeWar, pistolaAguaWar, giroRapido);

        //Blastoise 20
        Stats blasStats = new Stats(79, 83, 100, 85);
        Ataque hidroBomba = new Ataque("Hidro bomba", 55, 5, 80, elementos[2]);
        Ataque surf = new Ataque("Surf", 45, 15, 100, elementos[2]);
        Ataque mordiscoBlas = new Ataque("Mordisco", 30, 25, 100, elementos[17]);
        Ataque golpeCuerpo = new Ataque("Golpe cuerpo", 45, 15, 100, elementos[7]);
        pokemones[20] = new Pokemon("Blastoise", 50, blasStats, elementos[2], hidroBomba, surf, mordiscoBlas, golpeCuerpo);

        //Psyduck 21
        Stats psyStats = new Stats(50, 52, 48, 65);
        Ataque pistolaAguaPsy = new Ataque("Pistola agua", 20, 25, 100, elementos[2]);
        Ataque confusion = new Ataque("Confusion", 25, 25, 100, elementos[13]);
        Ataque golpeCabeza = new Ataque("Golpe cabeza", 35, 15, 100, elementos[7]);
        Ataque furia = new Ataque("Furia", 10, 20, 85, elementos[7]);
        pokemones[21] = new Pokemon("Psyduck", 30, psyStats, elementos[2], pistolaAguaPsy, confusion, golpeCabeza, furia);

        //Golduck 22
        Stats goldStats = new Stats(80, 82, 78, 95);
        Ataque surfGold = new Ataque("Surf", 45, 15, 100, elementos[2]);
        Ataque psíquico = new Ataque("Psiquico", 45, 10, 100, elementos[13]);
        Ataque golpeCuerpoGold = new Ataque("Golpe cuerpo", 42, 15, 100, elementos[7]);
        Ataque rayoHielo = new Ataque("Rayo hielo", 45, 10, 100, elementos[3]);
        pokemones[22] = new Pokemon("Golduck", 50, goldStats, elementos[2], surfGold, psíquico, golpeCuerpoGold, rayoHielo);

        //Poliwag 23
        Stats poliwagStats = new Stats(40, 50, 40, 40);
        Ataque burbujaPoli = new Ataque("Burbuja", 20, 30, 100, elementos[2]);
        Ataque hipnosis = new Ataque("Hipnosis", 30, 20, 60, elementos[13]);
        Ataque placajePoli = new Ataque("Placaje", 15, 20, 100, elementos[7]);
        Ataque pistolaAguaPoli = new Ataque("Pistola agua", 20, 25, 100, elementos[2]);
        pokemones[23] = new Pokemon("Poliwag", 30, poliwagStats, elementos[2], burbujaPoli, hipnosis, placajePoli, pistolaAguaPoli);

        //Seel 24
        Stats seelStats = new Stats(65, 45, 55, 45);
        Ataque pistolaAguaSeel = new Ataque("Pistola agua", 20, 25, 100, elementos[2]);
        Ataque cabezazoSeel = new Ataque("Cabezazo", 35, 15, 100, elementos[7]);
        Ataque auroraBeam = new Ataque("Rayo aurora", 33, 20, 100, elementos[3]);
        Ataque burbujaSeel = new Ataque("Burbuja", 20, 30, 100, elementos[2]);
        pokemones[24] = new Pokemon("Seel", 40, seelStats, elementos[2], pistolaAguaSeel, cabezazoSeel, auroraBeam, burbujaSeel);

        //Kingler 25
        Stats kinglerStats = new Stats(55, 130, 115, 50);
        Ataque surfKingler = new Ataque("Surf", 45, 15, 100, elementos[2]);
        Ataque martillazo = new Ataque("Martillazo", 45, 10, 85, elementos[2]);
        Ataque golpeCuerpoKingler = new Ataque("Golpe cuerpo", 42, 15, 100, elementos[7]);
        Ataque derriboKingler = new Ataque("Derribo", 45, 20, 85, elementos[7]);
        pokemones[25] = new Pokemon("Kingler", 50, kinglerStats, elementos[2], surfKingler, martillazo, golpeCuerpoKingler, derriboKingler);

        //Tentacool 26
        Stats tentaStats = new Stats(40, 40, 35, 100);
        Ataque ácido = new Ataque("Acido", 20, 30, 100, elementos[14]);
        Ataque pistolaAguaTenta = new Ataque("Pistola agua", 20, 25, 100, elementos[2]);
        Ataque constriccion = new Ataque("Constricción", 10, 35, 100, elementos[7]);
        Ataque burbujaTenta = new Ataque("Burbuja", 20, 30, 100, elementos[2]);
        pokemones[26] = new Pokemon("Tentacool", 40, tentaStats, elementos[2], ácido, pistolaAguaTenta, constriccion, burbujaTenta);

        //Placeholder
        Stats no = new Stats(1000, 1000, 1000, 1000);
        Ataque no0 = new Ataque("bajaprecision", 1, 100, 50, elementos[9]);
        Ataque no1 = new Ataque("tiene un pp", 100, 1, 100, elementos[0]);
        Ataque no2 = new Ataque("3", 100, 100, 100, elementos[0]);
        Ataque no3 = new Ataque("4", 1000, 100, 100, elementos[0]);
        pokemones[27] = new Pokemon("placeholder", 2000, no, elementos[0], no0, no1, no2, no3);



    }


    public Pokemon[] getPokemones(){  
        return pokemones;
 }

    public Pokemon getPlaceholder(){
        return pokemones[27];
    }


}


