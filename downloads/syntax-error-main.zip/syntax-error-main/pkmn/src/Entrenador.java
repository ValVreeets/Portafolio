/**
 * Contiene el nombre del entrenador y su equipo correspondiente en una lista de pokemones
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */




public class Entrenador {
    private String nombreEntrenador;
    private Pokemon[] pokemones;
    private boolean esJugador;

    public Entrenador(String nombre, boolean rol, Pokemon pokemon0, Pokemon pokemon1, Pokemon pokemon2){
        pokemones = new Pokemon[3];
        pokemones[0] = pokemon0; //podria hacerse con setters en una funcion afuera
        pokemones[1] = pokemon1;
        pokemones[2] = pokemon2;
        this.nombreEntrenador = nombre;
        this.esJugador = rol;
        
    }
   




    //Setters y Getters
    public String getNombre(){
        return nombreEntrenador;
    }
    public void setNombre( String nombre){
        nombreEntrenador = nombre;
    }
    public Pokemon[] getPokemones(){
        return pokemones;
    }
    public Pokemon getPokemon(int i){
        return pokemones[i];
    }
    public void setPokemon( Pokemon[] pokemones){
        this.pokemones = pokemones;
    }
    public boolean getJugador(){
        return esJugador;
    }
    public void setJugador (boolean rol){
        esJugador = rol;
    }




    
}