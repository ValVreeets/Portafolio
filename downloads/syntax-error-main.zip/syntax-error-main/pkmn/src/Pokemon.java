/**
 * Contiene el nombre, el elemento, los stats, los ataques, si esta debilitado o no y si es del jugador o no
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */

public class Pokemon {
    private String nombre;
    private double nivel;
    private Stats stats;
    private boolean debilitado;
    private Elemento elemento;
    private Ataque[] ataques;
    private boolean delJugador; 

    public Pokemon(String nombre, double nivel, Stats stats, Elemento elemento, Ataque ataque0, Ataque ataque1, Ataque ataque2, Ataque ataque3) {
        ataques = new Ataque[4];
        this.nombre = nombre;
        this.nivel = nivel;
        this.stats = stats;
        this.elemento = elemento;
        ataques[0] = ataque0;
        ataques[1] = ataque1;
        ataques[2] = ataque2;
        ataques[3] = ataque3;
        this.debilitado = false;
        delJugador = false; //si pertenece al jugador o no
    }

    //setters y getters
    public void setdelJugador(boolean respuesta){
        delJugador = respuesta;
    }
    public boolean getdelJugador(){
        return delJugador;
    }


    public String getNombre(){
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public double getNivel() {
        return nivel;
    }

    public void setNivel(double nivel) {
        this.nivel = nivel;
    }

    public Stats getStats() {
        return stats;
    }

    public void setStats(Stats stats) {
        this.stats = stats;
    }

    public boolean getDebilitado() {
        return debilitado;
    }

    public void isDebilitado(boolean debilitado) {
        this.debilitado = debilitado;
    }

    public Elemento getElemento() {
        return elemento;
    }

    public void setElemento(Elemento elemento) {
        this.elemento = elemento;
    }
    public Ataque[] getAtaques(){
        return ataques;
    }
    public Ataque getAtaque(int i){
        return ataques[i];
    }
    public void setAtaque(int i, Ataque ataque){
        ataques[i] = ataque;
    }
    

}
