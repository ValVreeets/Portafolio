import java.util.Scanner;
/**
 * Permite al usuario elegir a su equipo
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */
public class CrearJugador {
    private Pokemon[] pokemonesElegibles = new Pokemon[9];
    private Pokemon[] misPokemones;
    private boolean inputvalido;
    private int intSeleccionado;
    private int[] intelegido={200,300,500};
    private String nombreElegido;
    private Entrenador jugador;
    private Records records;

/**
 * 
 * @param misPokemones lista de pokemones elegidos por  el jugador
 * @param pkmnelegibles  lista de pokemones designados como opciones posibles para el jugador
 * @param records registro de actividades del jugador en el programa
 * @param listaTotal lista de todos los Pokemones existentes en el programa
 * @param intSeleccionado int que recibe eleccion de pokemon del usuario
 * @param nombreElegido guarda como nombre el string elegido por el jugador
 * @param inputvalido cuida que se chequee para cada eleccion el control de erorres
 * @param jugador Objeto Entrenador creado con la informacion recibida y seleccionada por el usuario
 * 
 */
    public CrearJugador(){
       
        misPokemones = new Pokemon[3];
        CrearPokemones pkmnelegibles = new CrearPokemones();
        records = new Records();
        Pokemon[] listaTotal = pkmnelegibles.getPokemones();

        pokemonesElegibles[0] = listaTotal[1];  //tepig
        pokemonesElegibles[1] = listaTotal[4];  //arcanine
        pokemonesElegibles[2] = listaTotal[7];  //chimchar
        pokemonesElegibles[3] = listaTotal[12]; //shinx
        pokemonesElegibles[4] = listaTotal[15]; //voltorb
        pokemonesElegibles[5] = listaTotal[16]; //raikou
        pokemonesElegibles[6] = listaTotal[18]; //squirtle
        pokemonesElegibles[7] = listaTotal[21]; //psyduck
        pokemonesElegibles[8] = listaTotal[27]; // 27 es placeholder q esta roto
 
        System.out.println("\nBienvenido a Pokemon!");
        System.out.println("Elige tu nombre entrenador: ");
        Scanner input = new Scanner(System.in);
        nombreElegido = input.nextLine();
        
        for(int i=0; i<9; i++){
            System.out.println((i+1)+") "+pokemonesElegibles[i].getNombre());    
        }

        System.out.println("Elije a los tres Pokemones que te seguiran en esta aventura: ");    
        for(int i=0; i<=2; i++){
            inputvalido=false;
            while(inputvalido==false){
                try{
                    intSeleccionado = (input.nextInt()-1);
                    if(intSeleccionado<=9 && intSeleccionado>=0){
                        if(intSeleccionado!=intelegido[0]&&intSeleccionado!=intelegido[1]){
                            intelegido[i]=intSeleccionado;
                            inputvalido=true;
                            System.out.println("Pokemon "+(i+1)+" elegido: "+pokemonesElegibles[intelegido[i]].getNombre());
                            if(i<2){
                                System.out.println("Elija su siguiente pokemon");
                            }
                        }
                        else{
                            System.out.println("Ese pokemon ya se eligio");
                        }
                    }
                    else{
                        System.out.println("Por favor elija un pokemon que este adentro de la lista");
                    }
                    
                }catch(Exception e){
                    System.out.println(e);
                    System.out.println("Por favor elija un numero valido");
                    input.next();
                }
            }  
        }
        
        
        
        for(int j =0; j<=2; j++){

            misPokemones[j]=pokemonesElegibles[intelegido[j]];
            misPokemones[j].setdelJugador(true);
            
        }
        jugador = new Entrenador(nombreElegido, true, misPokemones[0], misPokemones[1], misPokemones[2]);     

    }
    public Entrenador getJugador(){
            return jugador;
    }
    public Records getRecords(){
        return records;
    }
        
        
}
