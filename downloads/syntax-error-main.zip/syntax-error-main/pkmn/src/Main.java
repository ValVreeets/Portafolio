/**
 * Inicializa el juego
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */

public class Main {
    public static void main (String args[]){
        IniciarJuego juego1 = new IniciarJuego();
    }    
}