import java.util.Scanner;
import java.util.InputMismatchException;

/**
 * Permite al jugador elegir un int de un rango determinado, un pokemon de los pokemones no debilitidos y un ataque de los ataques que tienen mas de 0 pp
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */


public class Input {
     private static String nombreJugador; 
     public static void setNombreJugador(String nombre) {
        nombreJugador = nombre;
    }
    public Input(){
    }


/**
 * Permite al usuario elegir un int de un rango determinado
 * @param textoAlUsuario texto que se le quiere mostrar al usuario al momento de seleccionar una opcion
 * @param rangoMenor opcion mas pequena disponible
 * @param rangoMayor opcion mas grande disponibles
 * @return un int que representa la eleccion del usuario
 */
   
    public int elegirNumero( int rangoMenor , int rangoMayor , String textoAlUsuario){
        int input = -1;
        Scanner sc = new Scanner(System.in);
        while (input > rangoMayor || input < rangoMenor){
            try{
                System.out.println(textoAlUsuario);
                input = sc.nextInt();
            }catch (InputMismatchException e){
                System.out.println("Ingrese un numero, maestro pokemon.");
                sc.next();
                continue;
            }
            if ( input > rangoMayor || input < rangoMenor){
                System.out.println("Ese numero no esta entre las opciones, maestro pokemon");
            }
            
        }
        return input;   
    }
    
    
/**
 * Permite al jugador elegir un pokemon de los pokemones no debilitados
 * @param pokemones lista de Pokemones a recibir
 * @param pkmndebil booleano que determina si un pokemon en especifico esta debilitado
 * @param num eleccion de int del usuario
 * @return Pokemon seleccionado por el usuario
 */
    public Pokemon elegirPokemon2(Pokemon[] pokemones){
        boolean pkmndebil = true;
        int num=-1;
        System.out.println("");
        for(int i = 0; i<3; i++){
            if(pokemones[i].getDebilitado()==false){
                System.out.println((i+1)+"- "+pokemones[i].getNombre());
            }
        }
        while(pkmndebil==true){
            num = (elegirNumero(1,3,"\nElija un pokemon para continuar"))-1;
            pkmndebil=pokemones[num].getDebilitado();
            if(pkmndebil==true){
                System.out.println("Ese pokemon esta debilitado");
            }else{
                System.out.println("Has elegido a "+pokemones[num].getNombre());
            }
            System.out.printf("\n %s ha entrado a batalla. ", pokemones[num].getNombre());    
        }
        return pokemones[num];
    }
        

/**
 * Permite al jugador elegir un pokemon de los pokemones no debilitados
 * @param  pokemones lista de pokemones a recibir
 * @param  pokemonActivo Pokemon actualmente en el campo que pertenece al jugador 
 * @param  numDisp numero de pokemones aun disponible para luchar
 * @param disponibles lista de pokemones aun en capacidad de luchar
 * @param j contador que determina cual posicion de la lista disponibles es la disponible actualmete
 * @param contador numero especifico de cada opcion al momento de imprimir
 * @param num int que representa la eleccion del usuario
 * @param elegido pokemon electo por el usuario 
 * @return Pokemon escogido por el usuario 
 */
       public Pokemon elegirPokemon(Pokemon[] pokemones, Pokemon pokemonActivo){
                Pokemon elegido;  
                Pokemon[] disponibles;
                int numDisp = 0;
                for (Pokemon bicho : pokemones){
                    if (bicho.getDebilitado() == false && bicho != pokemonActivo){
                        numDisp++;
                    }
                }
                int j = 0;
                disponibles = new Pokemon [numDisp];
                System.out.print("\n");
                for(int i = 0; i<pokemones.length; i++){
                    if (pokemones[i].getDebilitado() == false && pokemones[i] != pokemonActivo){
                        disponibles[j] = pokemones[i];
                        j++;
                    }
                }
                int contador = 1;
                for (Pokemon bisho : disponibles){
                    System.out.println( contador+"- "+bisho.getNombre());
                    contador ++;
                }

                int num = (elegirNumero(1,numDisp,"\nElija un pokemon para continuar"))-1;
                elegido  = disponibles[num];
                System.out.printf("\n%s ha entrado a batalla. ", elegido.getNombre());
            
            return elegido;
    }


/**
 * Permite al usuario elegir un ataque de los ataques que tienen mas de 0 pp
 * @param PokeActual pokemon actualmente en el campo
 * @param ataques lista de ataques pertenecientes al pokeActual
 * @param pp cantidad de veces que se puede realizar un ataque en el mismo combate
 * @param num int elegido por el usuario para representar su eleccion de ataque 
 * @return el ataque escogido por el usuario
 */
    public Ataque elegirAtaque(Pokemon PokeActual ){
        Ataque[] ataques = PokeActual.getAtaques();
        int pp = 0;
        int num=-1;
        System.out.print( " \n" );
        for(int i = 0; i<4; i++){
            System.out.println((i+1)+ "- " + ataques[i].getNombre() + "  " + ataques[i].getPp()+ "/" + ataques[i].getogPP());
        }
        System.out.print( " \n" );
        while(pp==0){
            num = (elegirNumero(1,4,"Elija un ataque"))-1;
            pp=ataques[num].getPp();
            if(pp==0){
                System.out.println("No alcanza el pp");
            }else{
                ataques[num].setPp(pp-1);
            }
        }
        return ataques[num];
    }
}




