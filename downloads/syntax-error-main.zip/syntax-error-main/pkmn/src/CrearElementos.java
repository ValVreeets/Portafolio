/**
 * Crea los elementos en un espacio aparte y los coloca en una lista para generar mas orden visual
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */


public class CrearElementos {
    private Elemento[] elementos;
    
    public CrearElementos(){
        elementos = new Elemento[18];

        String[] debilidadesAcero = {"lucha","tierra","fuego"};
        String[] fortalezasAcero = {"normal","volador","roca","bicho","acero","planta","psiquico","hielo","dragon","hada"};
        String[] inmunidadesAcero = {"veneno"};
        elementos[0] = new Elemento("acero", debilidadesAcero, fortalezasAcero, inmunidadesAcero);

        String[] debilidadesVolador = {"roca","electrico","hielo"};
        String[] fortalezasVolador = {"lucha","bicho","planta"};
        String[] inmunidadesVolador = {"tierra"};
        elementos[1] = new Elemento("volador", debilidadesVolador, fortalezasVolador, inmunidadesVolador);

        String[] debilidadesAgua = {"planta","electrico"};
        String[] fortalezasAgua = {"fuego", "agua", "hielo", "acero"};
        String[] inmunidadesAgua = {"noHay"};
        elementos[2] = new Elemento("agua", debilidadesAgua, fortalezasAgua, inmunidadesAgua);
        
        String[] debilidadesHielo = {"lucha","roca","fuego","acero"};
        String[] fortalezasHielo = {"hielo"};
        String[] inmunidadesHielo = {"noHay"};
        elementos[3] = new Elemento("hielo", debilidadesHielo, fortalezasHielo, inmunidadesHielo);

        String[] debilidadesPlanta = {"volador","veneno","bicho","fuego","hielo"};
        String[] fortalezasPlanta = {"tierra","agua","planta","electrico"};
        String[] inmunidadesPlanta = {"noHay"};
        elementos[4] = new Elemento("planta", debilidadesPlanta, fortalezasPlanta, inmunidadesPlanta);

        String[] debilidadesBicho = {"volador","roca","fuego"};
        String[] fortalezasBicho = {"lucha","tierra","planta"};
        String[] inmunidadesBicho = {"noHay"};
        elementos[5] = new Elemento("bicho",debilidadesBicho, fortalezasBicho, inmunidadesBicho);

        String[] debilidadesElectrico = {"tierra"};
        String[] fortalezasElectrico = {"volador","electrico","acero"};
        String[] inmunidadesElectrico = {"noHay"};
        elementos[6] = new Elemento("electrico", debilidadesElectrico, fortalezasElectrico, inmunidadesElectrico);  
        
        String[] debilidadesNormal = {"lucha"};
        String[] fortalezasNormal = {"noHay"};
        String[] inmunidadesNormal = {"fantasma"};
        elementos[7] = new Elemento("normal", debilidadesNormal, fortalezasNormal, inmunidadesNormal);

        String[] debilidadesRoca = {"lucha","tierra","agua","planta","acero"};
        String[] fortalezasRoca = {"normal","volador","veneno","fuego"};
        String[] inmunidadesRoca = {"noHay"};
        elementos[8] = new Elemento("roca", debilidadesRoca, fortalezasRoca, inmunidadesRoca);

        String[] debilidadesTierra = {"agua","planta","hielo"};
        String[] fortalezasTierra = {"veneno","roca"};
        String[] inmunidadesTierra = {"electrico"};
        elementos[9] = new Elemento("tierra", debilidadesTierra, fortalezasTierra, inmunidadesTierra);

        String[] debilidadesFuego = {"tierra","roca","agua"};
        String[] fortalezasFuego = {"bicho","fuego","planta","acero","hielo","hada"};
        String[] inmunidadesFuego = {"noHay"};
        elementos[10] = new Elemento("fuego", debilidadesFuego, fortalezasFuego, inmunidadesFuego);

        String[] debilidadesLucha = {"volador","psiquico","hada"};
        String[] fortalezasLucha = {"roca","bicho","siniestro"};
        String[] inmunidadesLucha = {"noHay"};
        elementos[11] = new Elemento("lucha", debilidadesLucha, fortalezasLucha, inmunidadesLucha);

        String[] debilidadesHada = {"veneno","acero"};
        String[] fortalezasHada = {"lucha","bicho","siniestro"};
        String[] inmunidadesHada = {"dragon"};
        elementos[12] = new Elemento("hada", debilidadesHada, fortalezasHada, inmunidadesHada);

        String[] debilidadesPsiquico = {"bicho","fantasma","siniestro"};
        String[] fortalezasPsiquico = {"lucha","psiquico"};
        String[] inmunidadesPsiquico = {"noHay"};
        elementos[13] = new Elemento("psiquico", debilidadesPsiquico, fortalezasPsiquico, inmunidadesPsiquico);

        String[] debilidadesVeneno = {"tierra","psiquico"};
        String[] fortalezasVeneno = {"lucha","veneno","planta","bicho","hada"};
        String[] inmunidadesVeneno = {"noHay"};
        elementos[14] = new Elemento("veneno", debilidadesVeneno, fortalezasVeneno, inmunidadesVeneno);

        String[] debilidadesDragon = {"hielo","dragon","hada"};
        String[] fortalezasDragon = {"fuego","agua","planta","electrico"};
        String[] inmunidadesDragon = {"noHay"};
        elementos[15] = new Elemento("dragon", debilidadesDragon, fortalezasDragon, inmunidadesDragon); 

        String[] debilidadesFantasma = {"fantasma","siniestro"};
        String[] fortalezasFantasma = {"veneno","bicho"};
        String[] inmunidadesFantasma = {"normal","lucha"};
        elementos[16] = new Elemento("fantasma", debilidadesFantasma, fortalezasFantasma, inmunidadesFantasma);

        String[] debilidadesSiniestro = {"lucha","bicho","hada"};
        String[] fortalezasSiniestro = {"fantasma","siniestro"};
        String[] inmunidadesSiniestro = {"psiquico"};
        elementos[17] = new Elemento("siniestro", debilidadesSiniestro, fortalezasSiniestro, inmunidadesSiniestro);
    }
    public Elemento[] getElementos(){  
        return elementos;
    }
}
