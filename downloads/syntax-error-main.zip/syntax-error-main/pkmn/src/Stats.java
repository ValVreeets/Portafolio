/**
 * Contiene los stats de los pokemones
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */

public class Stats {
    private double hp;
    private double ogHP;
    private double atk;
    private double def;
    private int spd;

    public Stats(double hp, double atk, double def, int spd) {
        this.hp = hp;
        this.ogHP = hp;
        this.atk = atk;
        this.def = def;
        this.spd = spd;
    }


    //setters y getters 
    
    public double getHp() {
        return hp;
    }

    public void setHp(double hp) {  //Validacion para que hp no sea cero
        if ( hp < 0){
            this.hp = 0;
        }else{
            this.hp = hp;
        }
        
    }

    public double getogHP() {
        return ogHP;
    }

    public double getAtk() {
        return atk;
    }

    public void setAtk(double atk) {
        this.atk = atk;
    }

    public double getDef() {
        return def;
    }

    public void setDef(int def) {
        this.def = def;
    }

    public int getSpd() {
        return spd;
    }

    public void setSpd(int spd) {
        this.spd = spd;
    }
    public void restaurarHp(){
        this.hp = this.ogHP;
    }  
}    
