/**
 * Contiene todos los datos que se requieren para que se pueda ejecutar un ataque
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */


public class Ataque {
    private String nombre;
    private int potencia;
    private int pp;
    private int ogPP; // pp original 
    private int precision;  // definir pp maximo y pp actual 
    private Elemento elemento;
    public Ataque(String newnombre, int newpotencia, int newpp, int newprecision, Elemento newelemento){
        nombre = newnombre;
        potencia = newpotencia;
        pp = newpp;
        ogPP = pp;
        precision = newprecision;
        elemento = newelemento;
    }

   
    //Setter y Getters 
    public String getNombre(){
        return nombre;
    }
    public void setNombre(String nombre){
        this.nombre = nombre;
    }
    public int getPotencia(){
        return potencia;
    }
    public void setPotencia(int potencia){
        this.potencia = potencia;
    }
    public int getPp(){
        return pp;
    }
    public int getogPP(){
        return ogPP;
    }
    public void setPp(int pp){  //Validacion para no tener pp negativo  si es el ultimo uso 
        if ( pp < 0 ){
            this.pp = 0;
        }else {
            this.pp = pp;
        }
    }
    public int getPrecision(){
        return precision;
    }
    public void setPrecision(int precision){
        this.precision = precision;
    }
    public Elemento getElemento(){
        return elemento;   // objeto 
    }
    public void setElemento(Elemento elemento){
        this.elemento = elemento;
    }
    public void restaurarPp(){
        this.pp = this.ogPP;
    }

}
  