import java.util.Random;
/**
 * Permite al NPC elegir un pokemon random y un ataque random, ademas mantiene la cuenta de los enemigos totales
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */
public class AccionesNpc {
    private Random random = new Random();
    private Records records;
    public AccionesNpc( Records num){
        records = num;
    }
/**
 * Permite al NPC elegir un pokemon random de los que actualmente se encuentran disponibles
 * @param disponibles lista de Pokemones aun elegibles para combate
 * @param numDisp contador de cuantos Pokemones siguen vivos
 * @param j contador de los espacios en la lista de disponibles
 * @param randomNum numero aleatorio de entre el numero de pokemones disponibles
 * @param elegido pokemon seleccionado de entre las opciones
 * @return Pokemon aleatorio aun disponible
 */
    public Pokemon RandomPokemon(Pokemon[] pokemonesNpc){
        records.sumarTotalEnemies(1);
        Pokemon[] disponibles;
        int numDisp = 0;
        for (Pokemon bicho : pokemonesNpc){
            if (bicho.getDebilitado() == false){
                numDisp++;
            }
        }
        disponibles = new Pokemon [numDisp];
        int j = 0;
        for(int i = 0; i<pokemonesNpc.length; i++){
            if (pokemonesNpc[i].getDebilitado() == false){
                disponibles[j] = pokemonesNpc[i];
                j++;
            }
        }
        int randomNum = random.nextInt(numDisp);
        Pokemon elegido  = disponibles[randomNum];
        System.out.printf("\n%s ha entrado a batalla", elegido.getNombre());
        return elegido;
    }

/**
 * Permite al NPC elegir un ataque random de los ataques que tienen mas de 0 pp
 * @param ataques lista de los ataques existentes
 * @param num numero random para elegir ataque
 * @return ataque aleatorio de entre las opciones aun disponibles 
 */
    public Ataque RandomAtaque( Pokemon  PokemonRival){
        Ataque[] ataques = PokemonRival.getAtaques();
        int num = random.nextInt(4);
        while (ataques[num].getPp() == 0){
            num = random.nextInt(4);
        }
        return ataques[num];
    }




}
