/**
 * Contiene la cantidad de victorias, derrotas, enemigos, dano hecho, dano recibido, tiempo y tiempo final
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */


public class Records {
    private int victorias;
    private int derrotas;
    private long tiempoInicial;
    private long tiempoFinal;
    private double totalDMGReceived;
    private double totalDMG;
    private int totalEnemies;

    public Records(){
      victorias = 0; 
      derrotas = 0; 
      tiempoInicial = 0;
      tiempoFinal = 0;
      totalDMG = 0; 
      totalDMGReceived = 0; 
      totalEnemies = 0; 
    }


/**
 * getter del tiempo total
 * @param tiempo resta entre el tiempo inicial y el tiempo final
 * @return valor del tiempo de duracion del programa en minutos 
 */
    private double getTiempoTotal(){
        double tiempo = (tiempoFinal-tiempoInicial)/1000000000;
        tiempo = tiempo/60;
        return (tiempo);
    }


/**
 * Imprime los records
 * @param victorias combates ganados por el jugador
 * @param derrotas combates perdidos por el jugador
 * @param totalEnemies cantidad de pokemones con los que se peleo
 * @param totalDMG dano total hecho por los pokemones del jugador 
 * @param totalDMGReceived dano total recibido por el equipo del jugador 
 */
    public void imprimirRecords(){
        System.out.print( " \n REGISTRO DE SESION" );
        System.out.print( " \nılıılıılılıılıılıılıılıılılıılıılı" );
        System.out.print( "\nCombates ganados: " + victorias );
        System.out.print( "\nCombates perdidos : " + derrotas );
        System.out.print( "\nPokemones rivales: : " + totalEnemies );
        System.out.print( "\nTiempo total: " + getTiempoTotal() +" minutos");
        System.out.print( "\nDMG total realizado: " + totalDMG );
        System.out.print( "\nDMG total recibido: " + totalDMGReceived );

        

        System.out.print( " \nılıılıılılıılıılıılıılıılılıılıılı\n" );   
    }


    /**
     * Setter para total de enemigos
     * @param num valor para agregar al total de los enemigos batallados
     * @param totalEnemies total de enemigos con los que se lucho
     */
    public void sumarTotalEnemies( double num){
        totalEnemies += num;
    }






    //setters y getters
    public int getVictorias(){
        return victorias;
    }
    public void sumaVictorias( int num){
        victorias += num;
    }
    public int getDerrotas(){
        return derrotas;
    }
    public void  sumaDerrotas( int num){
        derrotas += num;
    }
    public long getTiempoInicial( ){
        return tiempoInicial;
    }
    public void setTiempoInicial( long num){
        tiempoInicial = num;
    }
     public long gettiempoFinal( ){
        return tiempoFinal;
    }
    public void settiempoFinal( long num){
        tiempoFinal = num;
    }
    public double getTotalDMG(){
        return totalDMG;
    }
    public void sumarTotalDMG( double dmg){
        totalDMG += dmg;
    }
    public double getTotalDMGReceived(){
        return totalDMGReceived;
    }
    public void sumartotalDMGReceived( double dmg){
        totalDMGReceived += dmg;
    }
    public int getTotalEnemies(){
        return totalEnemies;
    }



}
