/**
 * Coloca a los entrenadores en los gimnasios correspondientes para darle la estructura al juego
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */

public class CrearGimnasio {
    private Entrenador[] entrenadores;
    private Gimnasio[] gimnasios;

    public CrearGimnasio(){
        CrearEntrenadores creacioninicialentrenadores = new CrearEntrenadores();
        entrenadores = creacioninicialentrenadores.getEntrenadores();
        gimnasios = new Gimnasio[3]; 

        //Gimnasio Fuego gimnasios[0]
        gimnasios[0] = new Gimnasio( "Gimnasio Fuego", entrenadores[0], entrenadores[1], entrenadores[2] );
        //Gimnasio Electrico gimnasios[1]
        gimnasios[1] = new Gimnasio("Gimnasio Electrico", entrenadores[3], entrenadores[4], entrenadores [5]);
        //Gimnasio Agua gimnasios[2]
        gimnasios[2] = new Gimnasio("Gimnasio Agua", entrenadores[6], entrenadores[7], entrenadores [8]);
    }

    public Gimnasio[] getGimnasios(){
    return gimnasios;
    }
}
