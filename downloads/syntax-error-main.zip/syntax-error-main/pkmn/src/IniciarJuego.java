
import java.util.Scanner;
/**
 * Crea los gimnasios, crea al jugador, permite al jugador seleccionar el gimnasio, e inicia el loop de combate, y coloca todos los datos correspondientes en records
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */

public class IniciarJuego {
    private Gimnasio[] gimnasios;
    private Entrenador jugador;
    private Input input = new Input();
    private Scanner sc = new Scanner(System.in);
    private Records records;


 /**
 * Crea los gimnasios, crea al jugador, permite al usuario elegir un gimnasio, inicia el loop de combate, y coloca todos los datos correspondientes en records
 * @param gimnasios lista de gimnasios disponibles
 * @param jugador objeto entrenador del usuario
 * @param seguirJugando condicional que se vuelve falso si el jugador decide dejar de jugar
 * @param records registro que guarda informacion varia de la partida
 * @param inicioTiempo guarda el tiempo al iniciar el programa
 * @param inputGimnasio eleccion de usuario para el gimnasio
 * @param gimnasioElegido gimnasio seleccionado por el usuario
 * @param listaNpc lista de entrenadores que pertenecen al gimnasio elegido
 * @param numCombate contador para imprimir las batallas a realizar
 * @param finCombate condicional que determina cuando se acaba un combate especifico
 * @param wins combates ganados por el usuario
 * @param vivo condicional que determina si el jugador no ha perdido ningun combate
 * @param ganador Objeto entrenador que guarda la informacion del entrenador victorioso
 * @param placeholder Pokémon temporal que inicia funciones 
 */   
    public IniciarJuego(){   
        CrearGimnasio creacioninicialgimnasios = new CrearGimnasio();
        gimnasios=creacioninicialgimnasios.getGimnasios();
        CrearJugador creacionjugador = new CrearJugador();
        jugador=creacionjugador.getJugador();
        boolean seguirJugando = true;
        records = creacionjugador.getRecords();
        long inicioTiempo = System.nanoTime();
        records.setTiempoInicial(inicioTiempo);
        Calculos calcular = new Calculos(records);
       

        while(seguirJugando){
            restaurarEquipo(jugador);
            System.out.print("Gimnasios disponibles:");
            for (int i = 0; i<gimnasios.length; i++){
                System.out.print("\n"+(i+1)+") "+gimnasios[i].getNombre()); 
            }
            int inputGimnasio = (input.elegirNumero(1, gimnasios.length, "\nElije el gimnasio a retar:"))-1; //menos uno para que quede igual que la lista
            System.out.printf("Has elegido al poderosisimo %s.", gimnasios[inputGimnasio].getNombre());
            Gimnasio gimnasioElegido = gimnasios[inputGimnasio];
            Entrenador[] listaNpc = gimnasioElegido.getEntrenadores(); 
            for (Entrenador npc : listaNpc) {
                restaurarEquipo(npc);
            }
            int numCombate = 1;
            for (Entrenador trainer : listaNpc ){  //quedaria bonito hacer una presentacion especial para el lider 
                System.out.printf( "\nCombate #%d: %s VS %s", numCombate, jugador.getNombre(), trainer.getNombre());
                numCombate++;
            }
            AccionesNpc AccionesNpc = new AccionesNpc(records);
            boolean finCombate = false; //true si jugador o npc se quedan sin pokemones. Si es el jugador finJuego tambien cambia y debe hacer break al loop de entrenadores
            int wins = 0; //si llega a 3, victoria = true;
            boolean vivo = true; // para saber si sigue retando o para
            Entrenador ganador;
            CrearPokemones crear = new CrearPokemones();
            Pokemon placeholder = crear.getPlaceholder();
            CrearEntrenadores crearE = new CrearEntrenadores();
            ganador = crearE.getEntrenador(9); //placeholder

                for (Entrenador npc: listaNpc){
                    finCombate = false;
                        if (vivo == true){
                            if (npc == listaNpc[listaNpc.length-1]){
                                System.out.print("    ");                        
                                System.out.printf("\n\n--------Ronda final contra el lider de gimnasio %s------", npc.getNombre());
                            }else if(npc == listaNpc[listaNpc.length-2]){
                                System.out.printf("\n\n--------Segunda ronda contra %s--------------------------------", npc.getNombre());
                            }
                            //elegir pokemon jugador
                            System.out.print("\n \nInicio del combate.");
                            Pokemon pokemonActivo = input.elegirPokemon(jugador.getPokemones(), placeholder);

                            //npc elige pokemon random
                            Pokemon pokemonRival = AccionesNpc.RandomPokemon(npc.getPokemones());
                            calcular.imprimirVida(pokemonActivo,pokemonRival, jugador, npc); //PANTALLA
                            while (finCombate == false){ 
                                boolean turnosiguiente = true;
                                

                                System.out.print("\n 1- Atacar \n 2- Cambiar de Pokemon \n 3- Salir de Reto");
                                int opcionJugador = input.elegirNumero(1, 3, "\nElija su accion a tomar: ");
                                // OPT1) ataque
                                if (opcionJugador == 1){
                                    Ataque ataqueJugador = input.elegirAtaque(pokemonActivo);
                                    

                                    Pokemon[] orden = calcular.Velocidad( pokemonActivo, pokemonRival);
                                
                                    calcular.ejecutarAtaque(orden[0], pokemonActivo, pokemonRival, ataqueJugador);

                                    calcular.imprimirVida(pokemonActivo,pokemonRival, jugador, npc); //PANTALLA
                                
                                    //chequear si　queda hp a orden[1], y si toca cambiar pokenon o termina ronda 
                                    
                                    if (orden[1].getStats().getHp() == 0){ 
                                        orden[1].isDebilitado(true);
                                        turnosiguiente = false;
                                        if( orden[1].getdelJugador() == true){ //si es del jugador
                                            System.out.printf("OH NO.%s ha muerto.", orden[1].getNombre());
                                            if (calcular.chequearVidaEquipo(jugador.getPokemones()) == true){ //si aun hay vivos
                                                    pokemonActivo = input.elegirPokemon(jugador.getPokemones(), pokemonActivo);
                                                    calcular.imprimirVida(pokemonActivo,pokemonRival, jugador, npc); //PANTALLA
                                            }else {
                                                finCombate = true;
                                                ganador  = npc;
                                                records.sumaDerrotas(1);
                                            }
                                    
                                        } else{  //si es del npc
                                            System.out.printf("\n %s enemigo ha muerto.", orden[1].getNombre());
                                            if (calcular.chequearVidaEquipo(npc.getPokemones()) == true){ 
                                                pokemonRival = AccionesNpc.RandomPokemon(npc.getPokemones());
                                                calcular.imprimirVida(pokemonActivo,pokemonRival,jugador,npc); //PANTALLA
                                            }else {
                                                finCombate = true;
                                                ganador = jugador;
                                                records.sumaVictorias(1);
                                                
                                            }
                                        }

                                    }
                                    if (turnosiguiente ==true){
                                        calcular.ejecutarAtaque(orden[1], pokemonActivo, pokemonRival,ataqueJugador);

                                        calcular.imprimirVida(pokemonActivo,pokemonRival,jugador, npc); //PANTALLA

                                        //chequear si　queda hp a orden[0], y si toca cambiar pokenon o termina ronda 
                                        if (orden[0].getStats().getHp() == 0){ 
                                            orden[0].isDebilitado(true);

                                            if( orden[0].getdelJugador() == true){ //si es del jugador
                                                System.out.printf("OH NO.%s ha muerto.", orden[0].getNombre());
                                                System.out.printf("\n %s ha muerto.", orden[1].getNombre());
                                                if (calcular.chequearVidaEquipo(jugador.getPokemones()) == true){ //si aun hay vivos
                                                        pokemonActivo = input.elegirPokemon(jugador.getPokemones(), pokemonActivo);
                                                        calcular.imprimirVida(pokemonActivo,pokemonRival, jugador,npc); //PANTALLA
                                                }else {
                                                    finCombate = true;
                                                    ganador = npc;
                                                    records.sumaDerrotas(1);
                                                }
                                        
                                            } else {  //si es del npc
                                                System.out.printf("\n %s enemigo ha muerto.", orden[0].getNombre());
                                                if (calcular.chequearVidaEquipo(npc.getPokemones()) == true){

                                                    pokemonRival = AccionesNpc.RandomPokemon(npc.getPokemones());
                                                    calcular.imprimirVida(pokemonActivo,pokemonRival, jugador, npc); //PANTALLA
                                                }else {
                                                    finCombate = true;
                                                    ganador = jugador;
                                                    records.sumaVictorias(1);
                                                }
                                            }
                                        }
                                    }
                                } else if (opcionJugador == 2){//fin opcion 1

                                    // OPT2) Cambiar pokemon (jugador)
                                
                                    //elegir pkmn
                                    pokemonActivo = input.elegirPokemon(jugador.getPokemones(),pokemonActivo);
                                    
                                    //PANTALLA

                                    //ataque npc ( manda a cambiar hp por otra clase)
                                    calcular.ejecutarAtaque(pokemonRival, pokemonActivo, pokemonRival, null);
                                    calcular.imprimirVida(pokemonActivo,pokemonRival, jugador, npc); //PANTALLA

                                    //chequear hp pkmn activo si muere cambiar pokemon, sino hay finCombate == true
                                    if (pokemonActivo.getStats().getHp() == 0){
                                        pokemonActivo.isDebilitado(true);
                                        if (calcular.chequearVidaEquipo(jugador.getPokemones())  == true){
                                            pokemonActivo =  input.elegirPokemon(jugador.getPokemones(),pokemonActivo);
                                            calcular.imprimirVida(pokemonActivo,pokemonRival, jugador, npc); //PANTALLA
                                        }else{
                                            finCombate = true;
                                            ganador = npc;
                                        }
                                    }
                                    
                                //fin opcion 2

                                // Salir de todo
                                }else if (opcionJugador == 3){
                                    vivo = false; 
                                    finCombate = true;
                                }  

                            }  //FIN WHILE DEL COMBATE

                            if (ganador == jugador){
                                wins++; 

                            }else{
                                vivo = false;
                                System.out.printf("\n Fin de su intento en el Gimnasio %s.", gimnasioElegido.getNombre() );
                            }     

                        }//fin del condicional vivo = true 
                }
                //FIN DE LAS 3 RONDAS DE COMBATE

            if (wins == listaNpc.length && vivo == true){
                System.out.printf("\n VICTORIA. ERES EL NUEVO LIDER DEL %s", gimnasioElegido.getNombre());
            }
            System.out.print("\nDeseas retar un nuevo gimnasio o intentar vencer este nuevamente?\n 1) Si\n 2) No ");
            int respuesta = input.elegirNumero(1, 2, "");
            if (respuesta == 1) {
                System.out.println("Todos tus pokemones han sido restaurados.");
            } else {
                seguirJugando = false;
                long finalTiempo = System.nanoTime();
                records.settiempoFinal(finalTiempo);
                records.imprimirRecords();
                System.out.printf("\n Gracias por jugar. \n THE END \n .........?\n");

            }
            
            

        }
        sc.close();

    }// fin del constructor


/**
 * @param jugador Objeto entrenador con los datos del usuario
 */
    private void restaurarEquipo(Entrenador jugador) {
        for (Pokemon p : jugador.getPokemones()) {
            p.getStats().restaurarHp();
            for (Ataque a : p.getAtaques()) {
                a.restaurarPp();
            }
            p.isDebilitado(false);
        }
    
    }
    
}//fin de la clase 
