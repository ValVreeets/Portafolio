/**
 * Contiene las listas de debilidades, fortalezas e inmunidades de cada elemento
 * @author Andres, Valeria, Bryan
 * @version 1.1
 */



public class Elemento {
    private String nombre;
    private String[] debilidades;
    private String[] fortalezas;
    private String[] inmunidades;
    public Elemento(String nombre, String[] debilidades, String[] fortalezas, String[] inmunidades){
        this.nombre = nombre;
        this.debilidades = debilidades;
        this.fortalezas = fortalezas;
        this.inmunidades = inmunidades;
    }





// Setters y Getters
public String getNombre(){
    return nombre;
}
public void setNombre(String nombre){
    this.nombre = nombre;
}
public String[] getDebilidades(){
    return debilidades;
}
public void setDebilidades( String[] debilidades){
    this.debilidades = debilidades;
}
public String[] getFortalezas(){
    return fortalezas;
}
public void setFortalezas(String[] fortalezas){
    this.fortalezas = fortalezas;
}
public String[] getInmunidades(){
    return inmunidades;
}
public void setInmunidades(String[] inmunidades){
    this.inmunidades = inmunidades;
}




}
