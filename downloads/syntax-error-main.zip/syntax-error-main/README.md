
## Tareas programada #1 del grupo Syntax Error
Andrés Agüero Herrera C5C091  
Valeria Vargas Acosta B98132  
Bryan Jiménez Vindas C4G330  

El programa permite jugar batallas pokemon estilo gimnasio contra tres rivales potencialmente. Posee 3 opciones de gimnasio y 9 pokemones a elegir por el usuario. 
Para ganar un gimnasio y convertirse en el lider es necesario ganar todos los combates de forma seguido con minimo un pokemon aun de pie. 
De lo contrario el intento en ese gimnasio se detendra y el jugador debera reiniciar su intento o cerrar el programa.

EXTRA: si desea el modo exageradamente facil, utilice al pokemon 9 de la lista de opciones "placeholder".
nota: ataque 1 y ataque 2 poseen caracterisisticas peculiares a tomar en cuenta.

Para el buen funcionamiento del programa se necesitan las carpetas dentro de "Syntax Error":
-.git 
-.pkmn
Un programa que pueda correr Java.
Y el programa debe correrse minimo la primera vez desde desde la clase Main.

**Juego fanmade de Pokemon hecho sin fines de lucro.


